package actividad_gamificacion_12;
import java.io.FileReader;

/*
ENUNCIADO: Dado un fichero de texto, de nombre problema4.txt, visualizar el número de caracteres vocales, el número
de caracteres consonantes y el número de espacios en blanco contenidos en el fichero. Generar el fichero
problema4.txt con un editor de texto con el formato texto. 
 
AUTOR: Alex Ortiz García
*/
public class Actividad_4 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main(String [] args)throws Exception{
        new Actividad_4().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //CONSTANTES
        //Declaración constante tipo int para marcar el final del fichero
        final int FINAL_FICHERO=-1;
        //Declaración constante tipo char para almacenar el carácter Espacio
        final char ESPACIO=' ';
        //VARIABLES
        //Declaración variable tipo int para almacenar el código ascii
        //del carácter leído
        int codigo;
        //Declaración variable tipo char para almacenar el carácter leído
        char caracter;
        //Declaración variables tipo int para contabilizar el número de vocales,
        //consonantes y espacios en el fichero
        int contadorV, contadorC, contadorEsp;
        //Declaración objeto FileReader para habilitar la lectura del fichero
        FileReader fichero=new FileReader("problema4.txt"); 
        
        //ACCIONES
        //Inicialización variables contador
        contadorV=0;
        contadorC=0;
        contadorEsp=0;
        //Lectura del código del primer carácter
        codigo=fichero.read();
        //Bucle de tratamiento de busqueda para encontrar la primera vocal del
        //fichero problema2
        while (codigo!=FINAL_FICHERO){
            //Casteo a int de la variable codigo a la variable caracter
            caracter=(char)codigo;
            //Sentencias condicionales if para verificar si el carácter es
            //una vocal, una consonante o un espacio en blanco
            if (caracter=='a'||caracter=='e'||caracter=='i'||
                    caracter=='o'||caracter=='u'){
                contadorV++;
            }
            else if (caracter!='a'&&caracter!='e'&&caracter!='i'&&
                    caracter!='o'&&caracter!='u'&&caracter!=ESPACIO){
                contadorC++;
            }
            else {
                contadorEsp++;
            }
            codigo=fichero.read();
        }
        System.out.println("EN EL FICHERO HAY "+contadorV+" VOCALES, "
                + ""+contadorC+" CONSONANTES Y "+contadorEsp+" ESPACIOS EN BLANCO");
        //Cierre del enlace con el fichero
        fichero.close();
    }
}
