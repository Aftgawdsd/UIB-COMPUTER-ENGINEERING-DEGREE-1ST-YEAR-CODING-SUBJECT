package actividad_gamificacion_12;
import java.io.FileReader;

/*
ENUNCIADO: Dado un fichero de texto, de nombre problema2.txt, visualizar el primer carácter vocal contenido en el
fichero. En caso que no hubiese ningún carácter vocal se tiene que visualizar el mensaje correspondiente.
Generar el fichero problema2.txt con un editor de texto con el formato texto. 
 
AUTOR: Alex Ortiz García
 */
public class Actividad_2 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new Actividad_2().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //CONSTANTES
        //Declaración constante tipo int para marcar el final del fichero
        final int FINAL_FICHERO=-1;
        //VARIABLES
        //Declaración variable tipo int para almacenar el código ascii
        //del carácter leído
        int codigo;
        //Declaración variable tipo char para almacenar el carácter leído
        char caracter;
        //
        boolean vocal=false;
        //Declaración objeto FileReader para habilitar la lectura del fichero
        FileReader fichero=new FileReader("problema2.txt");
        
        //ACCIONES
        //Lectura del código del primer carácter
        codigo=fichero.read();
        //Bucle de tratamiento de busqueda para encontrar la primera vocal del
        //fichero problema2
        while (codigo!=FINAL_FICHERO){
            //Casteo a int de la variable codigo a la variable caracter
            caracter=(char)codigo;
            //Sentencia condicional if para verificar si el carácter
            //leído es una vocal
            if (caracter=='a'||caracter=='e'||caracter=='i'||
                    caracter=='o'||caracter=='u'){
                System.out.println("LA PRIMERA VOCAL DEL FICHERO ES "+caracter);
                vocal=true;
                break;
            }
            codigo=fichero.read();
        }
        if (!vocal){
            System.out.println("EN EL FICHERO NO HAY VOCALES");
        }
        //Cierre del enlace con el fichero
        fichero.close();
    }
}
