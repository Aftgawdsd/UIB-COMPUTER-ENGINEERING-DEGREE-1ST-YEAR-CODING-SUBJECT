package actividad_gamificacion_12;
import java.io.FileReader;

/*
ENUNCIADO: Dado un fichero de texto, de nombre problema3.txt, visualizar el número de parejas de caracteres ‘l’’a’
contenidas en el fichero. Generar el fichero problema3.txt con un editor de texto con el formato texto. 
 
AUTOR: Alex Ortiz García
*/
public class Actividad_3 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new Actividad_3().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //CONSTANTES
        //Declaración constante tipo int para marcar el final del fichero
        final int FINAL_FICHERO=-1;
        //VARIABLES
        //Declaración variable tipo int para almacenar el código ascii
        //del carácter leído
        int codigo;
        //Declaración variable tipo char para almacenar el carácter leído
        char caracter;
        //Declaración variable tipo int para contabilizar el número de parejas
        //'la' en el fichero
        int contador;
        //Declaración objeto FileReader para habilitar la lectura del fichero
        FileReader fichero=new FileReader("problema3.txt");
        
        //ACCIONES
        //Inicialización variable contador
        contador=0;
        //Lectura del código del primer carácter
        codigo=fichero.read();
        //Bucle de tratamiento de busqueda para encontrar la primera vocal del
        //fichero problema2
        while (codigo!=FINAL_FICHERO){
            //Casteo a int de la variable codigo a la variable caracter
            caracter=(char)codigo;
            //Sentencia condicional if para verificar si el carácter
            //leído es el carácter l
            if (caracter=='l'){
                codigo=fichero.read();
                caracter=(char)codigo;
                if (caracter=='a'){
                    codigo=fichero.read();
                    caracter=(char)codigo;
                    contador++;
                }
            }
            codigo=fichero.read();
        }
        System.out.println("EN EL FICHERO HAY "+contador+" PAREJAS 'la'");
        //Cierre del enlace con el fichero
        fichero.close();
    }
}
