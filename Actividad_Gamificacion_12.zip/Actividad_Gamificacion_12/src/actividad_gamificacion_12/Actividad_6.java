package actividad_gamificacion_12;
import java.io.FileWriter;
import java.io.FileReader;

/*
ENUNCIADO: Dado un fichero de texto, de nombre problema6.txt, generar dos ficheros, de nombres
problema6Vocales.txt y problema6Consonantes.txt de forma que el primero de ellos se escribirán todos
los caracteres vocales contenidos en el fichero problema6.txt y en el segundo fichero se escribirán todos
los caracteres consonantes contenidos en el fichero proble6.txt.
Todos los caracteres grabados en los dos ficheros de salida estarán separados con el carácter espacio.
 
AUTOR: Alex Ortiz García
*/
public class Actividad_6 {
    //MÉTODO MAIN
    public static void main(String [] args)throws Exception{
        new Actividad_6().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //CONSTANTES
        //Declaración constante int para almacenar el valor final del fichero
        final int FINAL_FICHERO=-1;
        //Declaración constante char para almacenar el carácter Espacio
        final char ESPACIO=' ';
        //VARIABLES
        //Declaración variable int para almacenar el código del carácter leído
        int codigo;
        //Declaración variable char para almacenar el carácter leído
        char caracter;
        //Declaración variable objeto FileReader para habilitar la lectura del 
        //fichero
        FileReader fichero1=new FileReader("problema6.txt");
        //Declaración variables objeto FileWriter para habilitar la escritura 
        //de ficheros
        FileWriter ficheroV=new FileWriter("problema6Vocales.txt");
        FileWriter ficheroC=new FileWriter("problema6Consonantes.txt");
        
        //ACCIONES
        //Lectura del código del primer carácter
        codigo=fichero1.read();
        //Bucle de tratamiento de recorrido 
        while (codigo!=FINAL_FICHERO){
            //Casteo a char de la variable codigo en la variable caracter
            caracter=(char)codigo;
            //Sentencia condicional if
            if (caracter=='a' || caracter=='e' || caracter=='i' ||
                    caracter=='o' || caracter=='u'){
                ficheroV.write(caracter+" ");
            }
            else if (caracter!='a' && caracter!='e' && caracter!='i' &&
                    caracter!='o' && caracter!='u' && caracter!=ESPACIO){
                ficheroC.write(caracter+" ");
            }
            codigo=fichero1.read();
        }
        //Cierre del enlace con los ficheros
        fichero1.close();
        ficheroV.close();
        ficheroC.close();
    }
}
