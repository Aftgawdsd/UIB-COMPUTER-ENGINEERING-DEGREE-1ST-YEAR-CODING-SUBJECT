package actividad_gamificacion_12;
import java.io.FileReader;

/*
ENUNCIADO: Dado un fichero de texto, de nombre problema1.txt, visualizar en pantalla el número de caracteres
vocales contenidos en dicho fichero. Generar el fichero problema1.txt con un editor de texto con el
formato texto. 

AUTOR: Alex Ortiz García
*/
public class Actividad_1 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main(String[] args) throws Exception{
        new Actividad_1().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //CONSTANTES
        //Declaración constante tipo int para almacenar el valor entero que determinará
        //el final del fichero
        final int FINAL_FICHERO=-1;
        //VARIABLES
        //Declaración variable tipo char que almacenará el carácter leído del 
        //fichero
        char caracter;
        //Declaración variable entera para almacenar de uno en uno 
        //los códigos de cararcteres leídos desde el fichero texto.txt
        int codigo;
        //Declaración variable tipo int que almacenará el número
        //de vocales en el fichero
        int contador;
        //Declaración objeto FileReader para habilitar la lectura del fichero
        //problema1.txt
        FileReader fichero=new FileReader("problema1.txt");
        
        //ACCIONES
        //Inicializació variable contador
        contador=0;
        //Lectura del código del primer carácter
        codigo=fichero.read();
        //Bucle de tratamiento de recorrido
        while (codigo!=FINAL_FICHERO){
            //Casteo a variable tipo char en la variable caracter
            caracter=(char)codigo;
            //Sentencia condicional if para verificar si es una vocal
            if (caracter=='a'||caracter=='e'||caracter=='i'||
                    caracter=='o'||caracter=='u'){
                contador++;
            }
            codigo=fichero.read();
        }
        //Visualización resultado
        System.out.println("EN EL FICHERO HAY "+contador+" VOCALES");
        //Cierre del enlace con el fichero problema1.txt
        fichero.close();
        
    }
}
