package actividad_gamificacion_12;
import java.io.FileWriter;
import java.io.FileReader;

/*
ENUNCIADO: Dado un fichero de texto, de nombre problema5.txt, generar un fichero, de nombre problema5Salida.txt
teniendo en cuenta que los caracteres minúsculas serán grabados en el fichero de salida como caracteres
mayúsculas. Generar el fichero problema5.txt con un editor de texto con el formato texto.
 
AUTOR: Alex Ortiz García
*/

public class Actividad_5 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new Actividad_5().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //CONSTANTES
        //Declaración constante tipo int para marcar el final del fichero
        final int FINAL_FICHERO=-1;
        //VARIABLES
        //Declaración variable tipo int para almacenar el código ascii
        //del carácter leído
        int codigo;
        //Declaración variable tipo char para almacenar el carácter en mayúscula
        int mayuscula;
        //Declaración objeto FileReader para habilitar la lectura del fichero
        FileReader fichero1=new FileReader("problema5.txt"); 
        //Declaración objeto FileWriter para habilitar la escritura en el fichero
        FileWriter fichero2=new FileWriter("problema5Salida.txt");
        
        //ACCIONES
        //Lectura del código del primer carácter
        codigo=fichero1.read();
        //Almacenamiento de la variable codigo - 32 para convertir el carácter
        //en mayúscula
        mayuscula=codigo-32;
        //Bucle de tratamiento de busqueda para encontrar la primera vocal del
        //fichero problema2
        while (codigo!=FINAL_FICHERO){
            fichero2.write(mayuscula);
            //Lectura del código del siguiente carácter
            codigo=fichero1.read();
            mayuscula=codigo-32;
        }
        //Cierre del enlace con el fichero
        fichero1.close();
        fichero2.close();
    }
}
