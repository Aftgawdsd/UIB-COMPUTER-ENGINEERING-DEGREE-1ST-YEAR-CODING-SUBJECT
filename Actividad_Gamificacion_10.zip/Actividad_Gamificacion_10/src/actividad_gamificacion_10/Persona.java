/*
CLASE PERSONA

AUTOR:Alex Ortiz García
*/
package actividad_gamificacion_10;

public class Persona {
    //DECLARACIÓN ATRIBUTOS
    //Declaración atributo de objeto para almacenar el nombre de la persona
    public String nombre;
    //Declaración atributo de objeto para almacenar la edad de la persona
    private int edad;
    //Declaración atributo de objeto para almacenar el nif de la persona
    private String nif;
    //Declaración atributo de objeto para almacenar el código postal
    private int codigoPostal;
    //Declaración atributo de objeto para almacenar la altura
    private double altura;
    //Declaración atributo de objeto para almacenar el peso
    private double peso;
    
    //MÉTODOS
    //MÉTODOS CONSTRUCTORES
    //Método constructor sin parámetros para posibilitar la instanciación de un objeto 
    //Persona inicializandólo a cero
    public Persona(){
        edad=0;
        codigoPostal=0;
        altura=0;
        peso=0;
    }
    //Método constructor con parámetros que posibilita la inicialización de un objeto Persona
    public Persona(String dato1,int dato2,String dato3,int dato4,double dato5,double dato6){
        nombre=dato1;
        edad=dato2;
        nif=dato3;
        codigoPostal=dato4;
        altura=dato5;
        peso=dato6;
    }
    //MÉTODOS FUNCIONALES QUE POSIBILITAN EL COMPORTAMIENTO DE UN OBJETO Persona
    //Método funcional que posibilita la lectura de un objeto Persona desde el Teclado
    public void readPersona()throws Exception{
        //Mensaje usuario 
        System.out.println("LECTURA OBJETO PERSONA");
        //Mensaje usuario para introducir nombre de objeto persona
        System.out.print("NOMBRE: ");
        //Lectura y almacenamiento en atributo de objeto nombre
        nombre=LT.readLine();
        //Mensaje usuario para introducir edad de objeto Persona
        System.out.print("EDAD: ");
        //Lectura y almacenamiento en atributo de objeto edad
        edad=LT.readInt();
        //Mensaje usuario para introducir nif de objeto Persona
        System.out.print("NIF: ");
        //Lectura y almacenamiento en atributo de objeto nif
        nif=LT.readLine();
        //Mensaje usuario para introducir codigo postal de objeto Persona
        System.out.print("CÓDIGO POSTAL: ");
        //Lectura y almacenamiento en atributo de objeto codigoPostal
        codigoPostal=LT.readInt();
        //Mensaje usuario para introducir altura de objeto Persona
        System.out.print("ALTURA EN CMS: ");
        //Lectura y almacenamiento en atributo de objeto altura
        altura=LT.readDouble();
        //Mensaje Usuario para introducir peso de objeto persona
        System.out.print("PESO: ");
        //Lectura y almacenamiento en atributo de objeto peso
        peso=LT.readDouble();
    }
    //Método funcional que permite la conversió a String de los datos introducidos
    public String toString(){
        //DECLARACIONES
        //Declaración variable tipo string para almacenar el resultado de convertir todos
        //los datos en un único string
        String conversion;
        
        //ACCIONES
        conversion="NOMBRE: "+nombre+"\nEDAD: "+edad+"\nNIF: "+nif+"\nCÓDIGO POSTAL: "+codigoPostal+""
                + "\nALTURA: "+altura+" cms\nPESO: "+peso+" kgs";
        
        //RETORNAR VALOR
        return conversion;
    } 
    //Método que permite calcular el IMC de un objeto Persona
    public int calculoIMC()throws Exception{
        //DECLARACIONES
        //Variables double
        double alturaM=altura/100;
        double imc=peso/(alturaM*alturaM);
        //Variable int
        int tipo;
        
        //ACCIONES
        //Sentencia condicional if
        if (imc<20){
            tipo=1;
        }
        else if (imc>=20 && imc<=25){
            tipo=2;
        }
        else {
            tipo=3;
        }
        return tipo;
    }
    //Método que permite verificar si un objeto Persona es mayor o menor de edad
    //en base a su edad
    public boolean menorEdad()throws Exception{
        //DECLARACIONES
        //Variables boolean
        boolean menorEdad=false;
        
        //Acciones
        //Sentencia condicional if
        if (edad<18){
            menorEdad=true;
        }
        else {
            menorEdad=false;
        }
        return menorEdad;
    }
    //Método que permite verificar si un objeto Persona es mayor de 65 en su atributo edad
    public boolean terceraEdad()throws Exception{
        //DECLARACIONES
        boolean terceraEdad=false;
                
        if (edad>65){
            terceraEdad=true;
        }
        else {
            terceraEdad=false;
        }
        return terceraEdad;
    }
    //Método que permite verificar si un objeto Persona vive en el código postal dado por parámetro
    public void viveCodigoPostal(int dato){
        //DECLARACIONES
        boolean viveCodigo=false;
        if (codigoPostal==dato){
           viveCodigo=true; 
        }
    }
        //MÉTODOS get's QUE POSIBILITAN EL ACCESO A LOS ATRIBUTOS
    public String getNombre(){
        return nombre;
    }
    public int getEdad(){
        return edad;
    }
    public String getNIF(){
        return nif;
    }
    public int getCodigoPostal(){
        return codigoPostal;
    }
    public double getAltura(){
        return altura;
    }
    public double getPeso(){
        return peso;
    }
    
    //MÉTODOS SET QUE POSIBILITAN LA MODIFICACION DE LOS ATRIBUTOS
    public void setNombre(String dato){
        nombre=dato;
    }
    public void setEdad(int dato){
        edad=dato;
    }
    public void setNIF(String dato){
        nif=dato;
    }
    public void setCodigoPostal(int dato){
        codigoPostal=dato;
    }
    public void setAltura(double dato){
        altura=dato;
    }
    public void setPeso(double dato){
        peso=dato;
    }
}
