package actividad_gamificacion_10;

/**
 *ENUNCIADO: Implementar un programa que declare un array de 5 objetos Persona y lleve a cabo la
inicialización de todos ellos a través del teclado. Posteriormente se llevará a cabo los
siguientes listados de visualización:
a. Visualización de los objetos Personas que sean menores de edad.
b. Visualización de los objetos Personas que sean mayores de edad.
c. Visualización de los objetos Personas que pertenezcan a la tercera edad.
d. Visualización de los objetos Personas que estén en su peso ideal.
e. Visualización de los objetos Personas que estén en sobrepeso. 
 *
 *AUTOR: Alex Ortiz García
 */
public class array5ObjetosPersona {
    //DECLARACIÓN ATRIBUTOS DE CLASE
    private static int MAX_PERSONAS=5;
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new array5ObjetosPersona().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //Declaración array 
        Persona [] array=new Persona[MAX_PERSONAS];
        
        //TRATAMIENTO
        //Subprograma para leer el array de objetos Persona
        lecturaPersona(array);
        //Subprograma para clasificar a los objetos persona según los criterios establecidos
        clasificarPersona(array);
        
    }
    public void lecturaPersona(Persona [] vector)throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<MAX_PERSONAS;indice++) {
            vector[indice]=new Persona();
            vector[indice].readPersona();
            System.out.println();
        }
        System.out.println();
    }
    public void clasificarPersona(Persona [] vector)throws Exception{
        //TRATAMIENTO
        //Subprograma que visualiza cuales objetos Persona son mayores o menores de edad
        menorMayor(vector);
        //Subprograma que visualiza los objetos Persona de tercera edad
        terceraEdadAux(vector);
        //Subprograma que clasifica en personas con un peso ideal y con sobrepeso
        clasificarPeso(vector);
    }
    public void menorMayor(Persona [] vector)throws Exception{
        //TRATAMIENTO
        System.out.println("MENORES DE EDAD: ");
        for (int indice=0;indice<vector.length;indice++){
            if (vector[indice].menorEdad()==true){
                System.out.print(vector[indice].nombre+"\n");
            }
        }
        System.out.println();
        System.out.println("MAYORES DE EDAD: ");
        for (int indice=0;indice<vector.length;indice++){
            if (vector[indice].menorEdad()==false){
                System.out.print(vector[indice].nombre+"\n");
            }
        }
        System.out.println();
    }
    public void terceraEdadAux(Persona[]vector)throws Exception{
        //TRATAMIENTO
        System.out.println("TERCERA EDAD: ");
        for (int indice=0;indice<vector.length;indice++){
            if (vector[indice].terceraEdad()==true){
                System.out.print(vector[indice].nombre+"\n");
            }
        }
        System.out.println();
    }
    public void clasificarPeso(Persona[]vector)throws Exception{
        //TRATAMIENTO
        System.out.println("PERSONAS CON UN PESO IDEAL: ");
        for (int indice=0;indice<vector.length;indice++){
            if (vector[indice].calculoIMC()==1){
                System.out.print(vector[indice].nombre+"\n");
            }
        }
        System.out.println();
        System.out.println("PERSONAS CON SOBREPESO: ");
        for (int indice=0;indice<vector.length;indice++){
            if (vector[indice].calculoIMC()==3){
                System.out.print(vector[indice].nombre+"\n");
            }
        }
        System.out.println();
    }
}
