package actividad_gamificacion_10;

/**
 *ENUNCIADO: Implementar un programa que declare dos objetos Persona, uno de ellos debe ser
inicializado en la declaración y el otro debe ser inicializado a través de la lectura por
teclado. Posteriormente llevar a cabo el cálculo de sus respectivos IMC y visualizar en
pantalla cada uno de ellos seguidos del mensaje correspondiente al resultado de su IMC.
 *
 *AUTOR: Alex Ortiz García
 */
public class usoClasePersona {
    //DECLARACIÓN MÉTODO MAIN 
    public static void main (String [] args)throws Exception{
        new usoClasePersona().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //Declaración variable objeto Persona instánciandolo con el constructor vacío
        Persona persona1=new Persona();
        //Declaración variable objeto Persona instanciándolo con el constructor que posibilita
        //la inicialización de los atributos del objeto Persona
        Persona persona2=new Persona("Joan Bennasser Bover",18,"50025063V",07005,173,75);
        
        //ACCIONES
        //Lectura por teclado del objeto Persona persona1
        persona1.readPersona();
        
        //VISUALIZACIÓN RESULTADO
        System.out.println(persona1.toString()+"\n");
        IMC(persona1);
        System.out.println(persona2.toString()+"\n");
        IMC(persona2);
    }
    public void IMC(Persona pers)throws Exception{
        if (pers.calculoIMC()==1){
            System.out.println(pers.nombre+" ESTÁ POR DEBAJO DEL PESO IDEAL\n");
        }
        else if (pers.calculoIMC()==2){
            System.out.println(pers.nombre+" ESTÁ EN SU PESO IDEAL\n");
        }
        else {
            System.out.println(pers.nombre+" TIENE SOBREPESO\n");
        }
    }
}
