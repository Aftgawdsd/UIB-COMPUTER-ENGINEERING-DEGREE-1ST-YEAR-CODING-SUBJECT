
package Taller2_clases_parciales;

/*
CLASE FicheroArticleInOut

ATRIBUTOS:
- OBJETO RandomAccessFile fichero

MÉTODOS:
- constructor(String nombreFichero)
- Lectura -> lectura(), lectura(int posición)
- lecturaString(int dimensión)
- Escritura -> escritura(Article article), escritura(Article article, int posición)
- escrituraString(String cadena, int dimensión)
- vacio()
- Métodos réplica de la clase RandomAccessFile (seek(), length(), ...)
- cierre()

DIMENSIÓN CAMPOS/ATRIBUTOS OBJETO Article:
- codi --> INT (4 BYTES)
- descripcio --> STRING (30 BYTES)
- quanitat --> INT (4 BYTES)
- esborrat --> BOOLEAN (1 BYTE)

AUTOR: Alex Ortiz García
*/

//IMPORTAR LIBRERÍAS
import java.io.*;

public class FicheroArticleInOut {

    //ATRIBUTOS
    //DECLARACIÓN OBJETO RandomAccesFile QUE PERMITE LA LECTURA/ESCRITURA DE UN 
    //OBJETO Article DESDE/EN EL FICHERO
    private RandomAccessFile fichero = null;
    
////////////////////////////////////////////////////////////////////////////////
//////////////////////////       MÉTODOS             ///////////////////////////                                                              
////////////////////////////////////////////////////////////////////////////////
    
    //MÉTODO CONSTRUCTOR
    public FicheroArticleInOut(String nombreFichero) throws Exception{
        try{
            //INICIALIZACIÓN DEL OBJETO RandomAccessFile fichero CON EL STRING nombreFichero
            //PASADO POR PARÁMETRO Y EL MODO rw, EL CUAL PERMITE LA LECTURA/ESCRITURA
            //DESDE/EN UN FICHERO
            fichero = new RandomAccessFile(nombreFichero, "rw");
        }
        catch(FileNotFoundException error){
            System.out.println("ERROR: "+error.toString());
        }
    }
    
    //MÉTODOS FUNCIONALES
    
    /*
    MÉTODOS LECTURA():
    - Normal
    - Por Posición
    */
    
    //MÉTODO LECTURA()
    //MÉTODO QUE POSIBILITA LA LECTURA DE UN OBJETO Article DESDE UN
    //FICHERO EXISTENTE
    public Article lectura() {
        //DECLARACIÓN E INICIALIZACIÓN DE OBJETO Article AUXILIAR
        Article article = new Article();
        
        try{
            //LECTURA ATRIBUTO codi
            article.setCodi(fichero.readInt());
            //LECTURA ATRIBUTO descripcio
            article.setDesc(lecturaString(Article.getDimDesc()));
            //LECTURA ATRIBUTO quantitat
            article.setQuant(fichero.readInt());
            //LECTURA ATRIBUTO esborrat
            article.setEsborrat(fichero.readBoolean());
        }
        catch(EOFException error){
            return null;
        }
        catch(IOException error){
            System.out.println("ERROR: " +error.toString());
        }
        //DEVUELVE EL OBJETO Article LEÍDO POR FICHERO
        return article;
    }
    
    //MÉTODO LECTURA(INT --> POSICIÓN)
    //MÉTODO QUE POSIBILITA LA LECTURA DE UN OBJETO Article POSICIONADO EN LA POSICIÓN
    //PASADA POR PARÁMETRO DESDE UN FICHERO EXISTENTE
    public Article lectura(int pos) {
        //DECLARACIÓN E INICIALIZACIÓN DE OBJETO Article AUXILIAR
        Article article = new Article();
        
        try{
            //VERIFICACIÓN DE SI LA POSICIÓN PASADA POR PARÁMETRO EXISTE EN EL 
            //FICHERO
            if ((pos > 0) && (pos <= (fichero.length()/Article.getDimReg()))){
                //POSICIONAMIENTO DEL PUNTERO A LA POSICIÓN PASADA POR PARÁMETRO
                //*SE RESTA 1 A POS PORQUE EMPIEZA DESDE 0
                fichero.seek((pos-1) * Article.getDimReg());
                //LECTURA ATRIBUTO codi
                article.setCodi(fichero.readInt());
                //LECTURA ATRIBUTO descripcio
                article.setDesc(lecturaString(Article.getDimDesc()));
                //LECTURA ATRIBUTO quantitat
                article.setQuant(fichero.readInt());
                //LECTURA ATRIBUTO esborrat
                article.setEsborrat(fichero.readBoolean());
            }
            else {
                throw new EntradaIncorrecta("<< !! >> POSICIÓN INEXISTENTE << !! >>");
            }
        }
        catch(EntradaIncorrecta error) {
            System.out.println("ERROR: " +error.toString());
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
        //DEVUELVE EL OBJETO Article LEÍDO POR FICHERO
        return article;
    }
    
    //MÉTODO LECTURASTRING(INT --> DIMENSIÓN STRING)
    //MÉTODO QUE LEE UN STRING DEL FICHERO Y LO DEVUELVE
    public String lecturaString(int dimension) {
        //DECLARACIÓN E INICIALIZACIÓN STRING resultado
        String resultado = "";
        
        try{
            //SENTENCIA ITERATIVA FOR HASTA QUE i > dimension 
            for (int i = 0; i<dimension; i++){
                resultado = resultado + fichero.readChar();
            }
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
        //DEVOLUCIÓN STRING resultado
        return resultado;
    }
    
    /*
    MÉTODOS ESCRITURA():
    - Normal
    - Por Posición
    */
    
    //MÉTODO ESCRITURA(ARTICLE --> AUX)
    //MÉTODO QUE POSIBILITA LA ESCRITURA DE UN OBJETO Article EN UN FICHERO
    public void escritura(Article aux){
        try{
            //POSICIONAMIENTO DEL PUNTERO DEL FICHERO AL FINAL
            fichero.seek(fichero.length());
            //ESCRITURA DEL ATRIBUTO codi EN EL FICHERO
            fichero.writeInt(aux.getCodi());
            //ESCRITURA DEL ATRIBUTO descripcio EN EL FICHERO
            escrituraString(aux.getDesc(), Article.getDimDesc());
            //ESCRITURA DEL ATRIBUTO quantitat EN EL FICHERO
            fichero.writeInt(aux.getQuant());
            //ESCRITURA DEL ATRIBUTO esborrat EN EL FICHERO
            fichero.writeBoolean(aux.getEsborrat());
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
    }
    
    //MÉTODO ESCRITURA(ARTICLE --> AUX, INT --> POSICIÓN)
    //MÉTODO QUE POSIBILITA LA ESCRITURA DE UN OBJETO Article EN UN FICHERO
    //EN LA POSICIÓN DADA
    public void escritura(Article aux, int pos) {
        try{
            //VERIFICAR SI LA POSICIÓN PASADA POR PARÁMETRO
            //EXISTE EN EL FICHERO
            if ((pos > 0) && (pos <= (fichero.length()/Article.getDimReg()))){
                //POSICIONAMIENTO DEL PUNTERO DEL FICHERO EN LA POSICIÓN CORRECTA
                fichero.seek((pos - 1) * Article.getDimReg());
                //ESCRITURA DEL ATRIBUTO codi EN EL FICHERO
                fichero.writeInt(aux.getCodi());
                //ESCRITURA DEL ATRIBUTO descripcio EN EL FICHERO
                escrituraString(aux.getDesc(), Article.getDimDesc());
                //ESCRITURA DEL ATRIBUTO quantitat EN EL FICHERO
                fichero.writeInt(aux.getQuant());
                //ESCRITURA DEL ATRIBUTO esborrat EN EL FICHERO
                fichero.writeBoolean(aux.getEsborrat());
            }
            else{
                throw new EntradaIncorrecta("<< !! >> POSICIÓN INEXISTENTE << !! >>");
            }
        }
        catch(EntradaIncorrecta error) {
            System.out.println("ERROR: " +error.toString());
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
    }
    
    //MÉTODO ESCRITURASTRING()
    //MÉTODO QUE PERMITE ESCRIBIR UN STRING EN EL FICHERO
    public void escrituraString(String cadena, int dimension) {
        try{
            //SENTENCIA ITERATIVA HASTA QUE EL AUXILIAR ÍNDICE i SEA MAYOR
            //QUE LA DIMENSIÓN PERMITIDA O LA LONGITUD DEL STRING PASADO
            //POR PARÁMETRO
            for (int i = 0; (i < dimension) && (i < cadena.length()); i++){
                //ESCRITURA DEL SIGUIENTE CARÁCTER DEL STRING PASADO
                //POR PARÁMETRO
                fichero.writeChar(cadena.charAt(i));
            }
            //SI EL STRING PASADO POR PARÁMETRO ES MENOR A LA DIMENSIÓN PERMITIDA
            if (cadena.length() < dimension){
                //SENTENCIA ITERATIVA FOR HASTA QUE EL AUXILIAR ÍNDICE i SEA
                //MAYOR A LA DIFERENCIA DE LA DIMENSIÓN MENOS LA LONGITUD DEL STRING
                for (int i = 0; i < (dimension - cadena.length()); i++){
                    //ESCRITURA DEL CARÁCTER ESPACIO
                    fichero.writeChar(' ');
                }
            }
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
    }
    
    //MÉTODO VACIO()
    //MÉTODO QUE DEVUELVE UN VALOR BOOLEANO BASADO EN EL HECHO DE SI 
    //ESTÁ VACÍO O NO
    public boolean vacio() throws IOException{
        return (fichero.length() == 0);
    }
    
    //MÉTODO SEEK(INT --> POSICIÓN)
    //MÉTODO QUE REPLICA LA FUNCIÓN SEEK DE RandomAccessFile
    public void seek(long posicion) throws IOException{
        fichero.seek(posicion);
    }
    
    //MÉTODO LENGTH()
    //MÉTODO QUE REPLICA LA FUNCIÓN LENGTH DE RandomAccessFile
    public long length() throws IOException{
        return fichero.length();
    }
    
    //MÉTODO GETFILEPOINTER()
    //MÉTODO QUE REPILCA LA FUNCIÓN GETFILEPOINTER DE RandomAccessFile
    public long getFilePointer() throws IOException{
        return fichero.getFilePointer();
    }
    
    //MÉTODO CIERRE()
    //MÉTODO QUE CIERRA EL ENLACE LÓGICO CON EL FICHERO
    public void cierre() {
        try{
            fichero.close();
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
    }
}

//DECLARACIÓN CLASE HIJA DE EXCEPTION EntradaIncorrecta
class EntradaIncorrecta extends Exception{
    public EntradaIncorrecta(String error){
        System.out.println(error);
    }
}
