
package Taller2_clases_parciales;

/*
CLASE FicheroIndexInOut

ATRIBUTOS:
- OBJETO RandomAccessFile fichero

MÉTODOS:
- constructor(String nombreFichero)
- Lectura -> lectura(), lectura(int posición)
- Escritura -> escritura(Article article), escritura(Article article, int posición)
- Métodos Réplica de la clase RandomFileAccess (seek(), length(), ...)
- cierre()

DIMENSIÓN CAMPOS/ATRIBUTOS OBJETO Index:
- posicio --> LONG (8 BYTES)
- codi --> INT (4 BYTES)

AUTOR: Alex Ortiz García
*/

//IMPORTAR LIBRERÍAS
import java.io.*;

public class FicheroIndexInOut {
    
    //ATRIBUTOS
    //DECLARACIÓN OBJETO RandomAccesFile QUE PERMITE LA LECTURA/ESCRITURA DE UN 
    //OBJETO Article DESDE/EN EL FICHERO
    private RandomAccessFile fichero = null;
    
////////////////////////////////////////////////////////////////////////////////
//////////////////////////       MÉTODOS             ///////////////////////////                                                              
////////////////////////////////////////////////////////////////////////////////
    
    //MÉTODO CONSTRUCTOR
    public FicheroIndexInOut(String nombreFichero) throws Exception{
        try{
            //INICIALIZACIÓN DEL OBJETO RandomAccessFile fichero CON EL STRING nombreFichero
            //PASADO POR PARÁMETRO Y EL MODO rw, EL CUAL PERMITE LA LECTURA/ESCRITURA
            //DESDE/EN UN FICHERO
            fichero = new RandomAccessFile(nombreFichero, "rw");
        }
        catch(FileNotFoundException error){
            System.out.println("ERROR: "+error.toString());
        }
    }
    
    //MÉTODOS FUNCIONALES
    
    /*
    MÉTODOS LECTURA():
    - Normal
    - Por Posición
    */
    
    //MÉTODO LECTURA()
    //MÉTODO QUE POSIBILITA LA LECTURA DE UN OBJETO Index DESDE UN FICHERO 
    //EXISTENTE
    public Index lectura() {
        //DECLARACIÓN E INICIALIZACIÓN OBJETO Index AUXILIAR
        Index index = new Index();
        
        try{
            //LECTURA ATRIBUTO posicio
            index.setPosicio(fichero.readLong());
            //LECTURA ATRIBUTO codi
            index.setCodi(fichero.readInt());
        }
        catch(EOFException error) {
            return null;
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
        //DEVUELVE EL OBJETO ARTICLE LEÍDO POR FICHERO
        return index;
    }
    
    //MÉTODO LECTURA(INT --> POSICIÓN)
    //MÉTODO QUE POSIBILITA LA LECTURA DE UN OBJETO Index EN LA POSICIÓN PASADA
    //POR PARÁMETRO DESDE UN FICHERO EXISTENTE
    public Index lectura(int pos) {
        //DECLARACIÓN E INICIALIZACIÓN OBJETO Index AUXILIAR
        Index index = new Index();
        
        try{
            //VERIFICAR SI EL OBJETO Index EN LA POSICIÓN PASADA POR PARÁMETRO
            //EXISTE EN EL FICHERO
            if ((pos > 0) && (pos <= (fichero.length()/Index.getDimInd()))){
                //POSICIONAMIENTO DEL PUNTERO A LA POSICIÓN PASADA POR PARÁMETRO
                //*SE RESTA 1 A POS PORQUE EMPIEZA DESDE 0
                fichero.seek((pos-1) * Index.getDimInd());
                //LECTURA ATRIBUTO posicio
                index.setPosicio(fichero.readLong());
                //LECTURA ATRIBUTO codi
                index.setCodi(fichero.readInt());
            }
            else{
                throw new EntradaIncorrecta("<< !! >> POSICIÓN INEXISTENTE << !! >>");
            }
        }
        catch(EOFException error) {
            return null;
        }
        catch(EntradaIncorrecta error) {
            System.out.println("ERROR: " +error.toString());
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
        //DEVUELVE EL OBJETO Index LEÍDO POR FICHERO
        return index;
    }
    
    /*
    MÉTODOS ESCRITURA:
    - Normal
    - Por Posición
    */
    
    //MÉTODO ESCRITURA(INDEX --> AUX)
    //MÉTODO QUE POSIBILITA LA ESCRITURA DEL OBJETO Index PASADO POR PARÁMETRO
    //EN UN FICHERO
    public void escritura(Index aux) {
        try{
            //POSICIONAMIENTO DEL PUNTERO EN EL FIN DEL FICHERO
            fichero.seek(fichero.length());
            //ESCRITURA DEL ATRIBUTO posicio EN EL FICHERO
            fichero.writeLong(aux.getPosicio());
            //ESCRITURA DEL ATRIBUTO codi EN EL FICHERO
            fichero.writeInt(aux.getCodi());
        }
        catch(IOException error){
            System.out.println("ERROR: " +error.toString());
        }
    }
    
    //MÉTODO ESCRITURA(INDEX --> AUX, INT --> POSICIÓN)
    //MÉTODO QUE POSIBILITA LA ESCRITURA DEL OBJETO Index
    //EN LA POSICIÓN PASADA POR PARÁMETRO EN UN FICHERO
    public void escritura(Index aux, int pos) {
        try{
            //VERIFICAR SI EL OBJETO Index EN LA POSICIÓN PASADA POR PARÁMETRO 
            //EXISTE DENTRO DEL FICHERO
            if ((pos > 0) && (pos <= (fichero.length()/Index.getDimInd()))){
                //POSICIONAMIENTO DEL PUNTERO EN LA POSICIÓN PASADA POR PARÁMETRO
                fichero.seek((pos - 1) * Index.getDimInd());
                //ESCRITURA ATRIBUTO posicio EN EL FICHERO
                fichero.writeLong(aux.getPosicio());
                //ESCRITURA ATRIBUTO codi EN EL FICHERO
                fichero.writeInt(aux.getCodi());
            }
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
    }
    
    //MÉTODO VACIO()
    //MÉTODO QUE DEVUELVE UN VALOR BOOLEANO BASADO EN EL HECHO DE SI 
    //ESTÁ VACÍO O NO
    public boolean vacio() throws IOException{
        return (fichero.length() == 0);
    }
    
    //MÉTODO SEEK(INT --> POSICIÓN)
    //MÉTODO QUE REPLICA LA FUNCIÓN SEEK DE RandomAccessFile
    public void seek(long posicion) throws IOException{
        fichero.seek(posicion);
    }
    
    //MÉTODO LENGTH()
    //MÉTODO QUE REPLICA LA FUNCIÓN LENGTH DE RandomAccessFile
    public long length() throws IOException{
        return fichero.length();
    }
    
    //MÉTODO GETFILEPOINTER()
    //MÉTODO QUE REPILCA LA FUNCIÓN GETFILEPOINTER DE RandomAccessFile
    public long getFilePointer() throws IOException{
        return fichero.getFilePointer();
    }
    
    //MÉTODO CIERRE()
    //MÉTODO QUE CERCENA EL ENLACE LÓGICO CON EL FICHERO
    public void cierre() {
        try{
            fichero.close();
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
    }
}

//DECLARACIÓN CLASE HIJA DE EXCEPTION EntradaIncorrecta
class EntradaIncorrecta extends Exception{
    public EntradaIncorrecta(String error){
        System.out.println(error);
    }
}
