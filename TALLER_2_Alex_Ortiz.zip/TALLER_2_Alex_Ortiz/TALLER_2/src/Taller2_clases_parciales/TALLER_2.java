
package Taller2_clases_parciales;

/*
CLASE PRINCIPAL TALLER 2

UTILIDAD: El programa a ejecutar permite realizar un total de 6 funciones
diferentes, las cuales son: 
1. Dar de alta un registro
2. Leer un registro a través de su código
3. Modificar un registro a través de su código
4. Borrar un registro a través de su código
5. Listar todos los artículos por orden de código
6. Listar todos los artículos con el orden que tienen en el fichero incluidos borrados
7. Salir del programa

AUTOR: Alex Ortiz García
*/

//IMPORTAR LIBRERÍAS
import java.io.*;

public class TALLER_2 {
    
    //ATRIBUTOS
    //DECLARACIÓN ATRIBUTO CONSTANTE QUE DETERMINA EL MÁXIMO DE OBJETOS ÍNDICE
    //A GENERAR
    private static final int MAX_INDEX = 10000;
    
    //MÉTODO MAIN
    public static void main(String [] args) throws Exception{
        new TALLER_2().metodoPrincipal();
    }
    public void metodoPrincipal() throws Exception{
        //DECLARACIONES
        //DECLARACIÓN E INICIALIZACIÓN DE UN OBJETO FicheroIndexInOut QUE PERMITE
        //LA LECTURA/ESCRITURA DE OBJETOS Index DESDE/EN FICHEROS
        FicheroIndexInOut ficheroIndex;
        //DECLARACIÓN E INICIALIZACIÓN DE UN OBJETO FicheroArticleInOut QUE PERMITE
        //LA LECTURA/ESCRITURA DE OBJETOS Article DESDE/EN FICHEROS
        FicheroArticleInOut ficheroArticles;
        //DECLARACIÓN E INICIALIZACIÓN DE UNA VARIABLE INT opcion QUE DETERMINA LA
        //OPCIÓN ESCOGIDA POR EL USUARIO
        int opcion = 0;
        
        try{
            //INICIALIZACIÓN OBJETOS FicheroIndexInOut y FicheroArticlesInOut
            ficheroIndex = new FicheroIndexInOut("index.dat");
            ficheroArticles = new FicheroArticleInOut("articles.dat");
            
            //SI EL FICHERO DE ÍNDICES ESTÁ VACÍO SE INICIALIZA
            //VERIFICAR SI EL FICHERO DE ÍNDICES ESTÁ VACÍO
            if(ficheroIndex.vacio()){
                //MÉTODO INICIARINDEX()
                iniciarIndex(ficheroIndex);
            }
            
            //SENTENCIA BUCLE WHILE HASTA QUE EL USUARIO INTRODUZCA 7
            while (opcion != 7){
                //TRATAMIENTO
                //VISUALIZACIÓN MENSAJE
                borrarPantalla("<<<< MENÚ PRINCIPAL >>>>"
                        + "\n1. DAR DE ALTA UN REGISTRO"
                        + "\n2. LEER UN REGISTRO A TRAVÉS DE SU CÓDIGO"
                        + "\n3. MODIFICAR UN REGISTRO A TRAVÉS DE SU CÓDIGO"
                        + "\n4. BORRAR UN REGISTRO A TRAVÉS DE SU CÓDIGO"
                        + "\n5. LISTAR TODOS LOS ARTÍCULOS POR ORDEN DE CÓDIGO"
                        + "\n6. LISTAR TODOS LOS ARTÍCULOS CON EL ORDEN QUE TIENEN EN EL FICHERO (INCLUIDOS BORRADOS)"
                        + "\n7. SALIR DEL PROGRAMA"
                        + "\n(1|2|3|4|5|6|7) : ");
                //LECTURA OPCIÓN ELEGIDA
                opcion = LT.readInt();
                //SENTENCIA SWITCH BASADA EN opcion
                switch(opcion){
                    case 1:{
                        //1. DAR DE ALTA UN REGISTRO
                        
                        borrarPantalla("<<<< DAR DE ALTA UN REGISTRO >>>>\n");
                        //MÉTODO AÑADIRREGISTRO()
                        añadirRegistro(ficheroIndex, ficheroArticles);
                        break;
                    }
                    case 2:{
                        //2. LEER UN REGISTRO A TRAVÉS DE SU CÓDIGO
                        
                        borrarPantalla("<<<< LEER REGISTRO A TRAVÉS DEL"
                                + " CÓDIGO >>>>\n");
                        //MÉTODO LEERREGISTRO()
                        leerRegistro(ficheroArticles);
                        
                        break;
                    }
                    case 3:{
                        //3. MODIFICAR UN REGISTRO A TRAVÉS DE SU CÓDIGO
                        
                        borrarPantalla("<<<< MODIFICAR REGISTRO A TRAVÉS "
                                + "DEL CÓDIGO >>>>\n");
                        //MÉTODO MODIFICARREGISTRO()
                        modificarRegistro(ficheroArticles);
                        
                        break;
                    }
                    case 4:{
                        //4. BORRAR UN REGISTRO A TRAVÉS DE SU CÓDIGO
                        
                        borrarPantalla("<<<< BORRAR REGISTRO A TRAVÉS "
                                + "DEL CÓDIGO >>>>\n");
                        //MÉTODO BORRARREGISTRO()
                        borrarRegistro(ficheroIndex, ficheroArticles);
                        
                        break;
                    }
                    case 5:{
                        //5. LISTAR TODOS LOS ARTÍCULOS POR ORDEN DE CÓDIGO
                        
                        borrarPantalla("<<<< LISTAR ARTÍCULOS POR ORDEN "
                                + "DE CÓDIGO >>>>\n");
                        //MÉTODO LISTARORDEN()
                        listarOrden(ficheroIndex, ficheroArticles);
                        
                        break;
                    }
                    case 6:{
                        //6. LISTAR TODOS LOS ARTÍCULOS CON EL ORDEN QUE TIENEN EN EL FICHERO
                        //INCLUIDO BORRADOS
                        
                        borrarPantalla("<<<< LISTAR ARTÍCULOS DEL FICHERO "
                                + "DE ARTÍCULOS DESORDENADO >>>>\n");
                        //MÉTODO LISTARDESORDEN()
                        listarDesorden(ficheroArticles);
                        
                        break;
                    }
                    case 7:{
                        //7. SALIR DEL PROGRAMA
                        
                        borrarPantalla("<<<< FIN DEL PROGRAMA >>>>\n");
                        
                        break;
                    }
                    default:{
                        //OPCIÓ NO VÁLIDA
                        
                        borrarPantalla("<< !! >> OPCIÓN NO VÁLIDA << !! >>");
                        
                        break;
                    }
                }
            }
            //CIERRE ENLACE LÓGICO DE FICHEROS
            ficheroIndex.cierre();
            ficheroArticles.cierre();
        }
        catch(IOException error){
            System.out.println("ERROR: " +error.toString());
        }
    }
    
    //MÉTODO BORRARPANTALLA(STRING --> MENSAJE)
    //MÉTODO QUE VACÍA PARCIALMENTE LA PANTALLA Y LA RENUEVA CON EL MENSAJE DESEADO
    private void borrarPantalla(String mensaje){
        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        System.out.print(mensaje);
    }
    
    //MÉTODO DE INICIALIZACIÓN
    
    //MÉTODO INICIARINDEX(FicheroIndexInOut --> FICHERO ÍNDICES
    //MÉTODO QUE ESCRIBE EN EL FICHERO DE ÍNDICES TODOS LOS OBJETOS Index
    //POSIBLES (MÁX. 10000 = MAX_IND)
    private void iniciarIndex(FicheroIndexInOut ficheroInd) throws IOException{
        //DECLARACIÓN E INICIALIZACIÓN OBJETO Index A ESCRIBIR EN EL FICHERO
        Index index = new Index();
        
        //SENTENCIA ITERATIVA FOR QUE ACABA CUANDO i ES MAYOR O IGUAL QUE 
        //LA CONSTANTE MAX_INDEX (10000)
        for (int i = 0; i < MAX_INDEX; i++) {
            //ESTABLECER ATRIBUTO codi DEL OBJETO Index A i + 1
            index.setCodi(i + 1);
            //ESTABLECER ATRIBUTO posicio DEL OBJETO Index A -1 (NO EXISTE/BORRADO)
            index.setPosicio(-1);
            //ESCRITURA OBJETO Index A FICHERO ficheroInd
            ficheroInd.escritura(index);
        }
    }
    
    //1. DAR DE ALTA UN REGISTRO
    //MÉTODO AÑADIRREGISTRO(FicheroIndexInOut --> FICHERO ÍNDICES, FicheroArticleInOut --> FICHERO DE ARTÍCULOS)
    //MÉTODO QUE AÑADE UN REGISTRO AL FICHERO DE ARTÍCULOS
    public void añadirRegistro(FicheroIndexInOut ficheroInd, FicheroArticleInOut ficheroArt) throws IOException{
        //POSICIONAMIENTO DEL PUNTERO DE FICHEROS A 0
        ficheroArt.seek(0);
        ficheroInd.seek(0);
        //DECLARACIÓN E INICIALIZACIÓN OBJETO Article A ESCRIBIR EN EL FICHERO
        Article article = new Article();
        //DECLARACIÓN OBJETO Article AUXILIAR
        Article aux;
        //DECLARACIÓN OBJETO Index A ESCRIBIR EN EL FICHERO
        Index index;
        
        //LECTURA DEL OBJETO Article A ESCRIBIR EN EL FICHERO
        article.lectura();
        //VERIFICAR QUE EL REGISTRO INTRODUCIDO NO EXISTA YA
        while (registroIgual(article, ficheroArt)){
            //LECTURA DEL OBJETO Article A ESCRIBIR EN EL FICHERO
            article.lectura();
        }
        //ESCRITURA DEL OBJETO Article 
        ficheroArt.escritura(article);

        //SENTENCIA ITERATIVA HASTA QUE i MAYOR O IGUAL QUE MAX_INDEX
        for (int i = 0; i < MAX_INDEX; i++) {
            //LECTURA SIGUIENTE OBJETO Index DEL FICHERO DE ÍNDICES
            index = ficheroInd.lectura();
            //VERIFICAR SI EL OBJETO Índice LEÍDO POR FICHERO TIENE
            //EL MISMO CÓDIGO QUE EL OBJETO Article LEÍDO POR TECLADO
            if (index.getCodi() == article.getCodi()){
                //POSICIONAMIENTO DEL PUNTERO DE FICHEROS A 0
                ficheroArt.seek(0);
                //SENTENCIA ITERATIVA FOR QUE ACABA CUANDO j ES MAYOR AL 
                //NÚMERO DE ELEMENTOS EN EL FICHERO DE ARTÍCULOS
                for (int j = 0; j < (int)(ficheroArt.length()/Article.getDimReg()); j++) {
                    //LECTURA SIGUIENTE OBJETO Article
                    aux = ficheroArt.lectura();
                    //VERIFICAR SI EL OBJETO Article LEÍDO POR FICHERO TIENE
                    //EL MISMO CÓDIGO QUE EL OBJETO Article LEÍDO POR TECLADO 
                    if (aux.getCodi() == article.getCodi()){
                        //ESTABLECER LA POSICIÓN DEL OBJETO ÍNDICE i EN j + 1
                        index.setPosicio(j);
                        //VISUALIZAR CÓDIGO Y POSICIÓN DEL OBJETO Índice
                        System.out.println("\n" +index.toString());
                    }
                }
                //ESCRITURA DEL ÍNDICE EN EL FICHERO
                ficheroInd.escritura(index,i);
            }
        }
        //VISUALIZAR MENSAJE
        System.out.println("\n<< !! >> REGISTRO DADO DE ALTA CORRECTAMENTE << !! >>");
    }
    
    //MÉTODO REGISTROIGUAL(Article --> ARTICLE, FicheroArticleInOut --> FCHERO ARTÍCULOS)
    //MÉTODO QUE VERIFICA SI EL OBJETO Article LEÍDO POR TECLADO
    private boolean registroIgual(Article article, FicheroArticleInOut ficheroArt) throws IOException{
        //POSICIONAMIENTO DEL PUNTERO DEL FICHERO DE ÍNDICES A 0
        ficheroArt.seek(0);
        //DECLARACIÓN DE OBJETO Article AUXILIAR
        Article aux;
        //SENTENCIA ITERATIVA FOR QUE ACABA CUANDO i ES MAYOR AL NÚMERO DE ELEMENTOS
        //EN EL FICHERO DE ARTÍCULOS
        for (int i = 0; i < (int)(ficheroArt.length()/Article.getDimReg()); i++){
            //LECTURA SIGUIENTE OBJETO Article DEL FICHERO
            aux = ficheroArt.lectura();
            //VERIFICAR SI EL CÓDIGO DEL OBJETO Article LEÍDO ES IGUAL AL OBJETO
            //Article PASADA POR PARÁMETRO
            if (aux.getCodi() == article.getCodi()){
                //VISUALIZAR MENSAJE
                System.out.println("<< !! >> REGISTRO YA EXISTENTE << !! >>\n");
                //SI SE DA EL CASO DEVUELVE TRUE
                return true;
            }
        }
        //SI PASA TODA LA SENTENCIA ITERATIVA SIN DEVOLVER NINGÚN VALOR, 
        //DEVUELVE FALSE
        return false;
    }
    
    //2. LEER REGISTRO A TRAVÉS DEL CÓDIGO
    //MÉTODO LEERREGISTRO(FicheroArticleInOut --> FICHERO DE ARTÍCULOS)
    //MÉTODO QUE PERMITE VISUALIZAR EN PANTALLA UN REGISTRO CONTENIDO EN 
    //EL FICHERO DE ARTÍCULOS QUE TENGA EL MISMO CÓDIGO 
    //QUE EL INTRODUCIDO POR TECLADO 
    public void leerRegistro(FicheroArticleInOut ficheroArt) throws IOException{
        //POSICIONAMIENTO DEL PUNTERO DEL FICHERO DE ARTÍCULOS A 0
        ficheroArt.seek(0);
        //VERIFICAR SI EL FICHERO ESTÁ VACÍO
        if (ficheroArt.vacio()) {
            //VISUALIZAR MENSAJE
            System.out.println("\n<< !! >> FICHERO VACÍO << !! >>");
        }
        else {
            //VISUALIZAR MENSAJE
            System.out.print("<<<< INTRODUZCA EL CÓDIGO A BUSCAR >>>>\nCÓDIGO: ");
            //DECLARACIÓN E INICIALIZACIÓN DE VARIABLE INT codigo QUE ALMACENARÁ
            //EL ENTERO INTRODUCIDO POR TECLADO
            int codigo = LT.readInt();
            //DECLARACIÓN E INICIALIZACIÓN DE VARIABLE BOOLEANA encontrado QUE
            //ESTABLECE SI SE HA ENCONTRADO EL REGISTRO CON EL CÓDIGO INTRODUCIDO
            //O NO
            boolean encontrado = false;
            //DECLARACIÓN OBJETO Article AUXILIAR
            Article aux;
            //SENTENCIA ITERATIVA FOR QUE ACABA CUANDO i ES MAYOR O IGUAL AL 
            //NÚMERO DE ELEMENTOS EN EL FICHERO DE ARTÍCULOS
            for (int i = 0; i < (int)(ficheroArt.length()/Article.getDimReg()); i++) {
                //LECTURA SIGUIENTE OBJETO Article DEL FICHERO
                aux = ficheroArt.lectura();
                //VERIFICAR SI EL OBJETO Article LEÍDO DEL FICHERO
                //TIENE EL MISMO CÓDIGO QUE EL INTRODUCIDO POR TECLADO
                if (aux.getCodi() == codigo) {
                    //VISUALIZAR REGISTRO
                    System.out.println(ficheroArt.lectura(i + 1));
                    //ESTABLECER ENCONTRADO A TRUE
                    encontrado = true;
                }
            }
            //SI NO SE HA ENCONTRADO EL REGISTRO VISUALIZA EL SIGUIENTE MENSAJE
            if (!encontrado) {
                //VISUALIZAR MENSAJE
                System.out.println("\n<< !! >> NO EXISTE UN REGISTRO CON ESE CÓDIGO << !! >>");
            }
        }
    }
    
    //3. MODIFICAR REGISTRO A TRAVÉS DEL CÓDIGO
    //MÉTODO MODIFICARREGISTRO()
    //MÉTODO QUE PERMITE MODIFICAR EL REGISTRO PASADO POR PARÁMETRO DEL FICHERO
    public void modificarRegistro(FicheroArticleInOut ficheroArt) throws IOException{
        //POSICIONAMIENTO DEL PUNTERO DEL FICHERO DE ARTÍCULOS A 0
        ficheroArt.seek(0);
        //DECLARACIÓN OBJETO Article AUXILIAR
        Article aux;
        //VERIFICAR SI EL FICHERO ESTÁ VACÍO
        if (ficheroArt.vacio()) {
            //VISUALIZAR MENSAJE
            System.out.println("\n<< !! >> FICHERO VACÍO << !! >>");
        }
        else{
        //VISUALIZAR MENSAJE
        System.out.print("<<<< INTRODUZCA EL CÓDIGO DEL REGISTRO A MODIFICAR >>>>\nCÓDIGO: ");
        //DECLARACIÓN Y LECTURA DEL CÓDIGO DEL REGISTRO A MODIFICAR DESDE EL 
        //TECLADO
        int codigo = LT.readInt();
        //DECLARACIÓN E INICIALIZACIÓN DE VARIABLE BOOLEANA encontrado
        //QUE DETERMINA SI EL OBJETO Article CON EL CÓDIGO INTRODUCIDO POR
        //TECLADO HA SIDO ENCONTRADO O NO
        boolean encontrado = false;
        //SENTENCIA ITERATIVA QUE ACABA CUANDO i ES MAYOR O IGUAL
        //AL NÚMERO DE ELEMENTOS EN EL FICHERO DE ARTÍCULOS
        for (int i = 0; i < (int)(ficheroArt.length()/Article.getDimReg()); i++) {
            //LECTURA SIGUIENTE OBJETO Article
            aux = ficheroArt.lectura();
            //VERIFICAR QUE EL OBJETO Article LEÍDO POR FICHERO TENGA EL MISMO 
            //CÓDIGO QUE EL INTRODUCIDO POR TECLADO
            if (aux.getCodi() == codigo) {
                //VISUALIZAR MENSAJE Y REGISTRO A MODIFICAR
                System.out.println("<<<< REGISTRO ANTIGUO >>>>\n" +ficheroArt.lectura(i+1)+ "\n");
                //ESTABLECER encontrado A TRUE
                encontrado = true;
                //VISUALIZAR MENSAJE
                System.out.print("<<<< INTRODUZCA LA NUEVA DESCRIPCIÓN >>>>\nDESCRIPCIÓN: ");
                //DECLARACIÓN Y LECTURA DE LA NUEVA DESCRIPCIÓN DEL REGISTRO
                String desc = LT.readLine();
                //ESTABLECER LA DESCRIPCIÓN DEL OBJETO Article A LA NUEVA
                //INTRODUCIDA POR TECLADO
                aux.setDesc(desc);
                //ESCRITURA DEL OBJETO Article EN LA POSICIÓN i + 1 EN EL FICHERO
                //DE ARTÍCULOS
                ficheroArt.escritura(aux,i + 1);
                //VISUALIZAR MENSAJE Y NUEVO REGISTRO
                System.out.println("\n<<<< NUEVO REGISTRO >>>>\n" +aux.toString()+ "\n");
            }
            }
            //VERIFICAR QUE HA SIDO ENCONTRADO EL OBJETO Article
            if (!encontrado) {
                //VISUALIZAR MENSAJE
                System.out.println("\n<< !! >> NO EXISTE UN REGISTRO CON ESE CÓDIGO << !! >>");
            }
            else {
                //
                System.out.println("\n<< !! >> REGISTRO MODIFICADO CORRECTAMENTE << !! >>\n");
            }
        }
    }
    
    //4. BORRAR REGISTRO A TRAVÉS DEL CÓDIGO
    //MÉTODO BORRARREGISTRO()
    //MÉTODO QUE PERMITE BORRAR LÓGICAMENTE EL REGISTRO CON EL CÓDIGO INTRODUCIDO POR TECLADO
    //EN EL FICHERO
    public void borrarRegistro(FicheroIndexInOut ficheroInd, FicheroArticleInOut ficheroArt) throws IOException{
        //POSICIONAMIENTO DEL PUNTERO DE LOS FICHEROS A 0
        ficheroInd.seek(0);
        ficheroArt.seek(0);
        //DECLARACIÓN DE OBJETO Index AUXILIAR
        Index indAux;
        //DECLARACIÓN DE OBJETO Article AUXILIAR
        Article artAux;
        //VERIFICAR SI EL FICHERO ESTÁ VACÍO
        if (ficheroArt.vacio()) {
            //VISUALIZAR MENSAJE
            System.out.println("\n<< !! >> FICHERO VACÍO << !! >>");
        }
        else{
            //VISUALIZAR MENSAJE
            System.out.print("\n<<<< INTRODUZCA EL CÓDIGO DEL REGISTRO A BORRAR >>>>\nCÓDIGO: ");
            //DECLARACIÓN Y LECTURA POR TECLADO DE CÓDIGO DEL REGISTO A BORRAR
            int codigo = LT.readInt();
            //LECTURA DEL OBJETO Index DESDE EL FICHERO DE ÍNDICES EN LA POSICIÓN
            //codigo
            indAux = ficheroInd.lectura(codigo);
            //VERIFICAR QUE EL OBJETO Index LEÍDO POR FICHERO EXISTA
            //O NO ESTÉ BORRADO
            if (indAux.getCodi() == -1){
                //VISUALIZAR MENSAJE
                System.out.println("\n<< !! >> NO EXISTE UN REGISTRO CON ESE CÓDIGO << !! >>\n");
            }
            //SI EXISTE
            else {
                //DECLARACIÓN E INICIALIZACIÓN DE LA POSICIÓN DEL OBJETO 
                //Article EN EL FICHERO DE ARTÍCULOS
                int posicion = (int)(indAux.getPosicio() + 1);
                //LECTURA DEL OBJETO Article EN LA POSICIÓN posicion EN EL 
                //FICHERO DE ARTÍCULOS
                artAux = ficheroArt.lectura(posicion);
                //MÉTODO BORRAR ESPECÍFICO DE LOS OBJETOS Article QUE ESTABLECE
                //EL ATRIBUTO BOOLEANO esborrat A TRUE
                artAux.borrar();
                //ESCRITURA DEL OBJETO Article artAux EN LA POSICIÓN posicion
                //DEL FICHERO DE ARTÍCULOS
                ficheroArt.escritura(artAux, posicion);
                //ESTABLECER LA POSICIÓN DEL OBJETO Index indAux A -1, YA QUE
                //HA SIDO BORRADO
                indAux.setPosicio(-1);
                //ESCRITURA DEL OBJETO INDEX IndAux EN LA POSICIÓN codigo
                //EN EL FICHERO DE ÍNDICES 
                ficheroInd.escritura(indAux, codigo);
                //VISUALIZAR MENSAJE
                System.out.println("\n<< !! >> REGISTRO BORRADO CORRECTAMENTE << !! >>\n");
            }
        }
    }
    
    //5. LISTAR ARTÍCULOS POR ORDEN DE CÓDIGO
    //MÉTODO LISTARORDEN(FicheroIndexInOut --> FICHERO DE ÍNDICES, FicheroArticleInOut --> FICHERO DE ARTÍCULOS)
    //* CONTIENE UN ERROR, A VECES LOS REGISTROS SE REPITEN DOS VECES AL VISUALIZAR EN PANTALLA
    //MÉTODO QUE LISTA TODOS LOS REGISTROS EN ORDEN DE CÓDIGO
    public void listarOrden(FicheroIndexInOut ficheroInd, FicheroArticleInOut ficheroArt) throws IOException{
        //POSICIONAMIENTO DEL PUNTERO DE LOS FICHEROS A 0
        ficheroInd.seek(0);
        ficheroArt.seek(0);
        //DECLARACIÓN DE OBJETO Article AUXILIAR 
        Article artAux;
        //DECLARACIÓN DE OBJETO Index AUXILIAR
        Index indAux;
        
        //VERIFICAR SI EL FICHERO ESTÁ VACÍO
        if (ficheroArt.vacio()) {
            //VISUALIZAR MENSAJE
            System.out.println("\n<< !! >> FICHERO VACÍO << !! >>");
        }
        else {
            //SENTENCIA ITERATIVA FOR QUE ACABA CUANDO i ES MAYOR O IGUAL AL NÚMERO 
            //DE ELEMENTOS Index EN EL FICHERO DE ÍNDICES
            for (int i = 0; i < MAX_INDEX; i++) {
                indAux = ficheroInd.lectura();
                //VERIFICAR QUE EL CÓDIGO DEL OBJETO Index LEÍDO EXISTA O NO ESTÉ BORRADO
                if (indAux.getCodi() != -1){
                    //POSICIONAR PUNTERO DEL FICHERO DE ARTÍCULOS A 0
                    ficheroArt.seek(0);
                    //SENTENCIA ITERATIVA FOR QUE ACABA CUANDO j ES MAYOR AL
                    //NÚMERO DE ELEMENTOS EN EL FICHERO DE ARTÍCULOS
                    for (int j = 0; j < (int)(ficheroArt.length()/Article.getDimReg()); j++) {
                        //LECTURA DEL SIGUIENTE OBJETO Article
                        artAux = ficheroArt.lectura();
                        //VERIFIAR QUE EL OBJETO Article LEÍDO TENGA EL MISMO CÓDIGO
                        //QUE EL OBJETO Index Y QUE NO ESTÉ BORRADO
                        if (artAux.getCodi() == indAux.getCodi() && (!artAux.getEsborrat())){
                            System.out.println(artAux.toString());
                        }
                    }
                }
            }
        }
    }
    
    //6. LISTAR POR ORDEN DE FICHERO ARTÍCULOS (INCLUSO BORRADOS)
    //MÉTODO LISTARDESORDEN()
    //MÉTODO QUE MUESTRA TODOS LOS ARTÍCULOS EN EL ORDEN DEL FICHERO DE
    //OBJETOS Article INCLUSO LOS BORRADOS
    public void listarDesorden(FicheroArticleInOut ficheroArt) throws IOException{
        //POSICIONAMIENTO DEL PUNTERO DEL FICHERO DE ARTÍCULOS A 0
        ficheroArt.seek(0);
        //DECLARACIÓN OBJETO Article A LEER DEL FICHERO
        Article article;
        try{
            //DECLARACIÓN E INICIALIZACIÓN VARIABLE INT contador QUE ALMACENA
            //EL RESULTADO CASTEADO A INT DEL COCIENTE ENTRE LA LONGITUD
            //EN BYTES DEL FICHERO DE OBJETOS Article Y EL TAMAÑO EN BYTES
            //DE UN OBJETO Article (69 BYTES)
            int contador = (int)(ficheroArt.length()/Article.getDimReg());
            
            //VERIFICAR SI EL FICHERO ESTÁ VACÍO
            if (ficheroArt.vacio()) {
                //VISUALIZAR MENSAJE
                System.out.println("\n<< !! >> FICHERO VACÍO << !! >>");
            }
            else{
                //SENTENCIA ITERATIVA FOR QUE ACABA CUANDO i ES MAYOR O IGUAL A contador
                for (int i = 0; i < contador; i++){
                    //LECTURA DEL SIGUIENTE OBJETO Article DESDE EL FICHERO
                    article = ficheroArt.lectura();
                    //VISUALIZAR OBJETO Article article
                    System.out.println(article.toString());
                }
            }
        }
        catch(IOException error) {
            System.out.println("ERROR: " +error.toString());
        }
    }
}
