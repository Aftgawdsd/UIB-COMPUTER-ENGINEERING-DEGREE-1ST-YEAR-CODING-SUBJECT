package Taller2_clases_parciales;

/*
CLASE Article

ATRIBUTOS:
- CODI --> int
- DESCRIPCIO --> String
- QUANTITAT --> int
- ESBORRAT --> boolean

MÉTODOS:
- Constructores -> vacío y por parámetro
- lectura()
- toString()
- Get's -> getCodigo(), getDesc(), getCantidad(), getEsborrat(), getMinCodi(),
    getMaxCodi(), getDimCodi(), getDimDesc(), getDimQuant(), getDimEsborr(),
    getDimReg()
- Set -> setCodigo(int codigo), setDesc(int desc), setCantidad(int cant), 
    setEsborrat(boolean borrar)
- borrar()

AUTOR ORIGINAL: Tomeu Estrany
AUTOR SECUNDARIO: Alex Ortiz García
*/

public class Article {

    //ATRIBUTOS
    //DECLARACIÓN ATRIBUTO INT codi QUE ALMACENA EL CÓDIGO DEL OBJETO
    //Article
    private int codi;
    //DECLARACIÓN ATRIBUTO STRING descripcio QUE ALMACENA LA DESCRIPCIÓN
    //DEL OBJETO Article
    private String descripcio;
    //DECLARACIÓN ATRIBUTO INT quantitat QUE ALMACENA LA CANTIDAD DEL
    //OBJETO Article
    private int quantitat;
    //DECLARACIÓN ATRIBUTO BOOLEAN esborrat QUE DETERMINA SI EL ARTÍCULO ESTÁ
    //BORRADO O NO
    private boolean esborrat = false;

    /*
    MÉDIDA DEL REGISTRO:
    - codi -> 4 BYTES
    - descripcio -> 30 CARACTERES * 2 BYTES POR CARÁCTER UNICODE = 60 BYTES
    - quantitat -> 4 BYTES
    - esborrat -> 1 BYTE
    
    TOTAL -> 4 + 4 + 30 + 1 = 69 BYTES
    */
    
    //DECLARACIÓN ATRIBUTO DE CLASE CONSTANTE QUE ALMACENA EL VALOR MÍNIMO DEL 
    //ATRIBUTO codi DE UN OBJETO Article
    private static final int MIN_CODI = 1;
    //DECLARACIÓN ATRIBUTO DE CLASE CONSTANTE QUE ALMACENA EL VALOR MÁXIMO DEL
    //ATRIBUTO codi DE UN OBJETO Article
    private static final int MAX_CODI = 10000;
    //DECLARACIÓN ATRIBUTO DE CLASE CONSTANTE QUE ALMACENA LOS TAMAÑOS EN BYTES
    //DE CADA UNO DE LOS ATRIBUTOS DE UN OBJETO Article
    private static final int DIM_CODI = 4;
    private static final int DIM_DESC = 30;
    private static final int DIM_QUANT = 4;
    private static final int DIM_ESBORR = 1;
    private static final int DIM_REG = DIM_CODI + 2*DIM_DESC + DIM_QUANT + DIM_ESBORR; 
    

////////////////////////////////////////////////////////////////////////////////
//////////////////////////       MÉTODOS             ///////////////////////////                                                              
////////////////////////////////////////////////////////////////////////////////
    
    //MÉTODOS CONSTRUCTORES
    
    //VACÍO
    public Article() {
        
    }
    
    //CON PARÁMETROS
    public Article(int codigo, String descripcion, int cantidad, boolean borrado) {
        this.codi = codigo;
        this.descripcio = descripcion;
        this.quantitat = cantidad;
        this.esborrat = borrado;
    }
    
    //MÉTODOS FUNCIONALES
    
    //MÉTODO LECTURA
    public void lectura() {
        //VISUALIZACIÓN MENSAJE
        System.out.println("<<<< LECTURA ARTÍCULO >>>>");
        //VISUALIZACIÓN MENSAJE
        System.out.print("CÓDIGO: ");
        //LECTURA ATRIBUTO codi
        this.codi = LT.readInt();
        
        //SENTENCIA BUCLE WHILE QUE ACABA SI  EL CÓDIGO INTRODUCIDO ESTÁ 
        //ENTRE LOS MÁRGENES ESTABLECIDOS
        while ((codi < MIN_CODI) || (codi > MAX_CODI)) {
            //VISUALIZAR MENSAJE
            System.out.print("<<< INTRODUZCA UN CÓDIGO VÁLIDO (1 - 10000) >>>>\n"
                    + "CÓDIGO: ");
            //LECTURA ATRIBUTO codi
            this.codi = LT.readInt();
        }
        
        //VISUALIZACIÓN MENSAJE
        System.out.print("DESCRIPCIÓN: ");
        //LECTURA ATRIBUTO descripcio
        this.descripcio = LT.readLine();
        //VISUALIZACIÓN MENSAJE
        System.out.print("CANTIDAD: ");
        //LECTURA ATRIBUTO quantitat
        this.quantitat = LT.readInt();
    }
    
    //MÉTODO TOSTRING
    @Override
    public String toString() {
        //DECLARACIÓN E INICIALIZACIÓN VARIABLE STRING conversion
        String conversion = codi+ ", " +descripcio+ ", " +quantitat;
        //RETORNO STRING conversion
        return conversion;
    }
    
    //MÉTODOS GET
    public int getCodi() {
        return this.codi;
    }
    public String getDesc() {
        return this.descripcio;
    }
    public int getQuant() {
        return this.quantitat;
    }
    public boolean getEsborrat() {
        return this.esborrat;
    }
    public static int getMinCodi() {
        return MIN_CODI;
    }
    public static int getMaxCodi() {
        return MAX_CODI;
    }
    public static int getDimCodi() {
        return DIM_CODI;
    }
    public static int getDimDesc() {
        return DIM_DESC;
    }
    public static int getDimQuant() {
        return DIM_QUANT;
    }
    public static int getDimEsborr() {
        return DIM_ESBORR;
    }
    public static int getDimReg() {
        return DIM_REG;
    }
    
    //MÉTODOS SET
    public void setCodi(int codigo) {
        this.codi = codigo;
    }
    public void setDesc(String desc) {
        this.descripcio = desc;
    }
    public void setQuant(int cantidad) {
        this.quantitat = cantidad;
    }
    public void setEsborrat(boolean borrado) {
        this.esborrat = borrado;
    }
    
    //MÉTODO BORRAR
    public void borrar() {
        this.esborrat = true;
    }
}