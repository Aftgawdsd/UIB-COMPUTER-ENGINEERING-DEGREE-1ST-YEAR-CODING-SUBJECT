package Taller2_clases_parciales;

/*
CLASE Index

ATRIBUTOS:
- POSICIO --> LONG
- CODI --> INT

MÉTODOS:
- toString()
- Get's --> getPosicio(), getCodi(), getDimCodi(), getDimPos(), getDimInd()
- Set's --> setPosicio(), setCodi()

AUTOR: Tomeu Estrany
AUTOR SECUNDARIO: Alex Ortiz García
 */
public class Index {
    
    //DECLARACIÓN ATRIBUTO INT posicio QUE ALMACENA LA POSICIÓN EN EL FICHERO
    //DEL OBJETO Index
    private long posicio;
    //ATRIBUTOS
    //DECLARACIÓN ATRIBUTO INT codi QUE ALMACENA EL CÓDIGO DEL OBJETO
    //Index
    private int codi;

    /*
    MÉDIDA DEL REGISTRO:
    - codi -> 4 BYTES
    - posicio -> 8 BYTES
    
    TOTAL -> 4 + 8 = 12 BYTES
    */
    
    //DECLARACIÓN ATRIBUTO DE CLASE CONSTANTE QUE ALMACENA LOS TAMAÑOS EN BYTES
    //DE CADA UNO DE LOS ATRIBUTOS DE UN OBJETO Index
    private static final int DIM_POS = 8;
    private static final int DIM_CODI = 4;
    private static final int DIM_IND = DIM_CODI + DIM_POS;
    
////////////////////////////////////////////////////////////////////////////////
//////////////////////////       MÉTODOS             ///////////////////////////                                                              
////////////////////////////////////////////////////////////////////////////////
    
    //MÉTODOS CONSTRUCTORES
    
    //VACÍO
    public Index (){

    }
    
    //PARÁMETROS
    public Index(long posicion, int codigo) {
        this.codi = codigo;
        this.posicio = posicion;
    }

    
    //MÉTODOS FUNCIONALES
    
    //MÉTODO TOSTRING()
    public String toString() {
        //DECLARACIÓN E INICIALIZACIÓN STRING conversion AUXILIAR
        String conversion = "CÓDIGO: " +this.codi+ " POSICIÓN: " +(this.posicio + 1);
        
        //DEVOLVER STRING AUXILIAR conversion
        return conversion;
    }
    
    //MÉTODOS GET
    public long getPosicio() {
        return this.posicio;
    }
    public int getCodi() {
        return this.codi;
    }
    public static int getDimCodi() {
        return DIM_CODI;
    }
    public static int getDimPos() {
        return DIM_POS;
    }
    public static int getDimInd() {
        return DIM_IND;
    }
    
    //MÉTODOS SET
    public void setPosicio(long posicion) {
        this.posicio = posicion;
    }
    public void setCodi(int codigo) {
        this.codi = codigo;
    }
    
}
