/*
ENUNCIADO:  dada una secuencia de caracteres introducida por teclado y acabada 
con el carácter ‘.’ visualiza las palabras constituidas por un número par de caracteres consonantes.


AUTOR: Alex Ortiz García
*/
package actividad_gamificacion_7;

public class Actividad_1 {
    private static 
    public static void main(String[] args) throws Exception {
        
    }
    
}
