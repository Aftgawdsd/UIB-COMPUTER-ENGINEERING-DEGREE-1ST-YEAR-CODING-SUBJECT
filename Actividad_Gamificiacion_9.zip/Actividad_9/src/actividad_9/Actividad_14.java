/*
ENUNCIADO: Realizar un programa que cree un array de números enteros cuya dimensión (número de
componentes) será introducida por teclado a petición del programa. Después llevar a término
la asignación de valores a cada una de las componentes del array introduciéndolos por teclado.
Por último visualizar el contenido del array indicando tanto el número de componente como
el contenido o valor de dicha componente.
Nota: tanto la asignación de valores por teclado como la visualización tiene que llevarse a
término a través de subprogramas.

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_14 {
     //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new Actividad_14().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        int dimension;
        //ACCIONES
        System.out.print("INTRODUZCA EL NÚMERO DESEADO DE COMPONENTES DEL ARRAY: ");
        dimension=LT.readInt();
        //TRATAMIENTO
        //Declaración array
        int [] array=new int[dimension];
        //Subprograma rellenar array
        rellenarArray(array);
        //Subprograma
        visualizarArray(array);

    }
    public void rellenarArray(int [] array)throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<array.length;indice++){
            System.out.print("INTRODUZCA EL COMPONENTE "+(indice+1)+": ");
            array[indice]=LT.readInt();
        }
    }
    public void visualizarArray(int [] array)throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<array.length;indice++){
            System.out.print(array[indice]+" ");
        }
        System.out.println();
    }
}
