/*
ENUNCIADO: Realizar un programa que vaya solicitando números enteros mientras que no se introduzca el
cero y rellene dos vectores, uno con los números pares, y otro con los números impares. El
máximo número de números a introducir será de 25. Al final, se debe mostrar por pantalla, por
separado, tanto los números pares como los impares.

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_12 {
    //DECLARACIÓN ATRIBUTOS
    public static final int LONGITUD_MAX=25;
    public static final int LONGITUD=25;
    public static final int FINAL=0;
    public static int ind1=0;
    public static int ind2=0;
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception{
        new Actividad_12().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        int [] pares=new int[LONGITUD];
        int [] impares=new int[LONGITUD];
        //TRATAMIENTO
        rellenarArrays(pares, impares);
        visualizarArrays(pares, impares);
    }
    public void rellenarArrays(int [] pares,int [] impares)throws Exception{
        //DECLARACIONES
        int numero;
        //ACCIONES
        System.out.print("INTRODUZCA UN NÚMERO ENTERO: ");
        numero=LT.readInt();
        //TRATAMIENTO
        for (int posicion=0;posicion<LONGITUD_MAX && numero!=FINAL;posicion++){
            System.out.print("INTRODUZCA UN NÚMERO ENTERO: ");
            numero=LT.readInt();
            if (numero%2==0){
                pares[ind1]=numero;
                ind1++;
            }
            else{
                impares[ind2]=numero;
                ind2++;
            }
        }
        
    }
    public void visualizarArrays(int [] pares,int [] impares)throws Exception{
        //TRATAMIENTO
        System.out.println("PARES");
        for (int indice=0;indice<ind1;indice++){
            System.out.print(pares[indice]+" ");
        }
        System.out.println();
        System.out.println("IMPARES");
        for (int index=0;index<ind2;index++){
            System.out.print(impares[index]+" ");
        }
        System.out.println();
    }
}
