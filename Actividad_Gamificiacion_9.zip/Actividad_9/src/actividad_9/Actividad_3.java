/*
ENUNCIADO:  declara un array de 100 componentes con los valores del 1 al 100. 
Visualiza la suma de todas las componentes y la
media. Utiliza los métodos que creas convenientes. 

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_3 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception{
        new Actividad_3().metodoPrincipal();
    }
    public void metodoPrincipal() throws Exception{
        //DECLARACIONES
        //CONSTANTES
        final int LONGITUD=100;
        //VARIABLES
        int [] numero=new int [LONGITUD];
        int res1;
        float res2;
        
        //TRATAMIENTO
        //Subprograma para obtener los 100 elementos del array
        rellenarArray(numero);
        //Subprograma para sumar los 100 elementos del array
        res1=(int)sumarArray(numero);
        //Media aritmética de los 100 primeros números naturales
        res2=(float)res1/LONGITUD;
        //VISUALIZACIÓN RESULTADO
        System.out.println("LA MEDIA DE LOS "+LONGITUD+" PRIMEROS NÚMEROS NATURALES ES "+res1+"\nSU MEDIA ES "+res2);
    }
    public void rellenarArray(int [] numero1)throws Exception{
        //DECLARACIONES
        int elemento=1;
        //TRATAMIENTO
        for (int indice=0;indice<numero1.length;indice++){
            numero1[indice]=elemento;
            elemento++;
        }
    }
    public int sumarArray(int [] numero2) throws Exception{
        //DECLARACIONES
        int suma=0;
        //TRATAMIENTO
        for (int indice=0;indice<numero2.length;indice++){
            suma=suma+numero2[indice];
        }
        return(suma);
    }
    
}
