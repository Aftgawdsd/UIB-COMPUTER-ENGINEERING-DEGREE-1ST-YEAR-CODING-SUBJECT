/*
ENUNCIADO:  declara un array de 5 componentes, asígnale valores
numéricos enteros por teclado y visualiza todas las
componentes por pantalla. Utiliza un método para la asignación 
y otro para la visualización. 

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_1 {
    //DECLARACIÓN ATRIBUTOS
    //CONSTANTES
    public static final int LONGITUD=5;
    //VARIABLES
    public static int [] array=new int [LONGITUD];
    public static void main(String[] args)throws Exception{
        new Actividad_1().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //TRATAMIENTO
        //Subprograma lectura array
        lecturaArray();
        //Subprograma visualización array
        visualizacionArray();
    }
    public void lecturaArray()throws Exception{
        //
        for (int indice=0;indice<array.length;indice++){
            System.out.print("INTRODUZCA UN NÚMERO: ");
            array[indice]=LT.readInt();
        }
    }
    public void visualizacionArray()throws Exception{
        //
        for (int indice=0;indice<array.length;indice++){
            System.out.print(array[indice]);
        }
        System.out.println();
    }
    
}
