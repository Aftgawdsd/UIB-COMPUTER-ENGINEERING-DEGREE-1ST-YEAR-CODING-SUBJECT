/*
ENUNCIADO: Realizar un programa que pida el valor de 10 números enteros distintos. Si se da el caso de
introducir un número repetido, el programa advertirá al usuario, y solicitará nuevamente el
número hasta que sea diferente de todos los anteriores. A continuación, el programa visualizará
los 10 números por pantalla.

AUTOR: Alex Ortiz García
 */
package actividad_9;

/**
 *
 * @author aog05
 */
public class Actividad_11 {
    //DECLARACIÓN ATRIBUTOS
    public static int LONGITUD=10;
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new Actividad_11().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        int [] enteros=new int[LONGITUD];
        //TRATAMIENTO
        rellenarArray(enteros);
        visualizarArray(enteros);
    }
    public void rellenarArray(int [] numeros)throws Exception{
        //DECLARACIONES
        int numero=0;
        int posicion=0;
        int contador=0;
        //ACCIONES
        for (int indice=0;indice<LONGITUD;indice++){
            System.out.print("INTRODUZCA 10 NÚMEROS ENTEROS DISTINTOS: ");
            numero=LT.readInt();
            numeros[indice]=numero;
            posicion++;
            for (int index=0;index<posicion;index++){
                if (numero-numeros[index]==0){
                    contador++;
                }
                if (contador==2){
                    indice--;
                    posicion--;
                    System.out.println("INTRODUZCA UN NÚMERO DISTINTO A LOS DEMÁS");
                }
            }
            contador=0;
        } 
    }
    public void visualizarArray(int [] numeros2)throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<LONGITUD;indice++){
            System.out.print(numeros2[indice]+" ");
        }
        System.out.println();
    }
}
