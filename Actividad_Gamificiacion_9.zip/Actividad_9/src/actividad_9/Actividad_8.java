/*
ENUNCIADO: Realizar un programa que dados dos arrays de 10 componentes enteras, inicializados en la
declaración, cree un tercer array asignándole como valor la resta, componente a componente,
de los dos primeros arrays. Posteriormente llevar a cabo la visualización siguiendo el siguiente
formato:
RESTA DE DOS ARRAYS
Valor 2 array 1 - Valor 2 array 2 = resultado resta array 3

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_8 {
    //DECLARACIÓN ATRIBUTOS
    //CONSTANTES
    public static final int LONGITUD=10;
    //VARIABLES
    public static int [] numeros1={1,2,3,4,5,6,7,8,9,10};
    public static int [] numeros2={10,9,8,7,6,5,4,3,2,1};
    public static int [] numeros3=new int[LONGITUD];
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new Actividad_8().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //TRATAMIENTO
        //Subprograma para obtener los componentes del tercer array
        rellenarArray();
        //Subprograma para visualizar el tercer array
        visualizarArray();
    }
    public void rellenarArray()throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<LONGITUD;indice++){
            numeros3[indice]=numeros1[indice]-numeros2[indice];
        }
    }
    public void visualizarArray()throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<LONGITUD;indice++){
            System.out.print(numeros1[indice]+" - "+numeros2[indice]+" = "+numeros3[indice]);
            System.out.println();
        }
    }
}
