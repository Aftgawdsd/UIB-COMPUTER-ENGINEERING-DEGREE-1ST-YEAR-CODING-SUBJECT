/*
ENUNCIADO: : declara un array de 10 componentes inicializándolas con valores numéricos 
enteros variados y visualiza la media
aritmética de dichos valores. 
Utiliza un método para calcular la media aritmética

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_2 {
    //DECLARACIONES
    //CONSTANTES
    public static final int LONGITUD=10;
    //VARIABLES
    public static int [] numeros=new int[LONGITUD];
    
    public static void main (String [] args) throws Exception{
          new Actividad_2().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //variable resultado
        int resultado;
        //TRATAMIENTO
        //Lectura array mediante subprograma lecturaArray
        lecturaArray();
        //Media aritmética de los elementos del array
        resultado=mediaAritmetica();
        //VISUALIZACIÓN RESULTADO
        System.out.println("LA MEDIA ARITMÉTICA DE LOS NÚMEROS INTRODUCIDOS POR TECLADO ES "+resultado);
                         
    }
    public void lecturaArray()throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<numeros.length;indice++){
            System.out.print("INTRODUZCA UN NÚMERO: ");
            numeros[indice]=LT.readInt();
        }
    }
    public int mediaAritmetica()throws Exception{
        //DECLARACIONES
        //VARIABLES
        //Variable int suma
        int suma=0;
        int media;
        //TRATAMIENTO
        for (int indice=0;indice<numeros.length;indice++){
            suma=suma+numeros[indice];
        }
        //Media aritmética
        media=suma/LONGITUD;
        //Retorno de valor
        return media;
    }
}
