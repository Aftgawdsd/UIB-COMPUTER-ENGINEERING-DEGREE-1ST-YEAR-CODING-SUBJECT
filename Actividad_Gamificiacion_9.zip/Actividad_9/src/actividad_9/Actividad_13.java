/*
ENUNCIADO: Dados los datos electorales de un municipio en el que se han presentado 10 partidos políticos,
visualiza los resultados generales siguiendo el siguiente formato...

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_13 {
    //DECLARACIÓN ATRIBUTOS
    public static final int LONGITUD=10;
    public static final String [] PARTIDOS={"ROJO","AZUL","VERDE","AMARILLO"
            ,"VIOLETA","MAGENTA","ROSA","MARRON","BLANCO ","NEGRO"};
    public static final int [] VOTOS={105,203,102,56,32,56,32,45,342,27};
    public static double [] porcentajes=new double[LONGITUD];
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new Actividad_13().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        double TotalVotos;
        //TRATAMIENTO
        //Subprograma total votos 
        TotalVotos=votosTotales();
        //Subprograma porcentajes
        porcentajeVotos(TotalVotos);
        //Subprograma visualizar resultados
        visualizarResultados();
    }
    public double votosTotales()throws Exception{
        //DECLARACIONES
        int suma=0;
        //TRATAMIENTO
        for (int indice=0;indice<VOTOS.length;indice++){
            suma=suma+VOTOS[indice];
        }
        return suma;
    }
    public void porcentajeVotos(double Total)throws Exception{
        //DECLARACIONES
        double operacion;
        //TRATAMIENTO
        for (int indice=0;indice<porcentajes.length;indice++){
            operacion=(VOTOS[indice]*100)/Total;
            porcentajes[indice]=operacion;
        }
    }
    public void visualizarResultados()throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<porcentajes.length;indice++){
            System.out.println("PARTIDO "+PARTIDOS[indice]+" "
                    + "-> número de votos: "+VOTOS[indice]+"   porcentaje: "+porcentajes[indice]+" %");
        }
    }
}
