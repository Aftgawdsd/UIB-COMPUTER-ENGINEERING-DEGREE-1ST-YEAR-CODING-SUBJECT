/*
ENUNCIADO: Realizar un programa que teniendo para cada Comunidad Autónoma el número de contagios
COVID habidos durante el último mes visualice la Comunidad con más contagios y la media de
contagios a nivel nacional. La visualización debe seguir el siguiente formato:

COMUNIDAD CON MÁS CONTAGIOS: nombre de la Comunidad
MEDIA NACIONAL DE CONTAGIOS: XXXXXX


AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_10 {
    //DECLARACIÓN ATRIBUTOS
    public static final int [] CONTAGIOS={1652850,467274,268718,163904,24968,858044,
        620641,472303,2690319,314454,762301,317028,469131,2012867,
        25817,259711,801227,111944,1597054};
    public static final String [] CCAA={"ANDALUCÍA","ARAGÓN","ASTURIAS","CANTABRIA","CEUTA","CASTILLA Y LEÓN",
        "CASTILLA LA-MANCHA","CANARIAS","CATALUÑA","EXTREMADURA","GALICIA","ISLAS BALEARES","MURCIA","MADRID",
        "MELILLA","NAVARRA","PAÍS VASCO","LA RIOJA","COMUNIDAD VALENCIANA"};
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception{
        new Actividad_10().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        int mayorNum;
        //TRATAMIENTO
        //Subprograma para ver el mayor componente del array contagios
        mayorNum=mayorContagios();
        //Subprograma para ver la CCAA correspondiente con la variable mayorNum
        visualizarCCAA(mayorNum);
        //Subprograma para visualizar la media de contagios a nivel nacional
        mediaContagios();
    }
    public int mayorContagios()throws Exception{
        //DECLARACIONES
        int mayor=0;
        for (int indice=0;indice<CONTAGIOS.length;indice++){
            if (mayor<CONTAGIOS[indice]){
                mayor=CONTAGIOS[indice];
            }
        }
        return mayor;
    }
    public void visualizarCCAA(int numContagios)throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<CCAA.length;indice++){
            if (numContagios==CONTAGIOS[indice]){
                System.out.println("COMUNIDAD CON MÁS CONTAGIOS: "+CCAA[indice]);
            }
        }
    }
    public void mediaContagios()throws Exception{
        //DECLARACIONES
        int suma=0;
        int resultado;
        //TRATAMIENTO
        for (int indice=0;indice<CCAA.length;indice++){
            suma=suma+CONTAGIOS[indice];
        }
        resultado=suma/CONTAGIOS.length;
        System.out.println("MEDIA NACIONAL DE CONTAGIOS: "+resultado);
    }
}
