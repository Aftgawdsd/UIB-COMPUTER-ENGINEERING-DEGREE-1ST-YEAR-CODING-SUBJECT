/*
ENUNCIADO: Realizar un programa que, dados dos arrays de 10 componentes enteras, inicializados en la
declaración, verifiquen si son iguales o no.

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_7 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception{
        new Actividad_7().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        int [] array1={1,2,3,4,5,6,7,8,9,10};
        int [] array2={1,2,3,4,5,6,7,8,9,10};
        boolean igualdad=false;
        //TRATAMIENTO
        //Subprograma para verificar la igualdad de los arrays
        igualdad=verificarIgualdad(array1,array2);
        if (igualdad==true){
            System.out.println("LOS DOS ARRAYS SON IGUALES");
        }
        else{
            System.out.println("LOS DOS ARRAYS SON DISTINTOS");
        }
        
    }
    public boolean verificarIgualdad(int[]enteros1,int[]enteros2)throws Exception{
        //DECLARACIONES
        boolean igual=false;
        int compo=0;
        //TRATAMIENTO
        for (int indice=0;indice<enteros1.length;indice++){
            if (enteros1[indice]==enteros2[indice]){
                compo++;
            }
        }
        if (compo==enteros1.length){
            igual=true;
        }
        return igual;
    }
}
