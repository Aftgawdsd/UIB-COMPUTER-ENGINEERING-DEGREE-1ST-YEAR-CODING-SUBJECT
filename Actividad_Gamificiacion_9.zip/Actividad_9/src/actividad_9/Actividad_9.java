/*
ENUNCIADO: Realizar un programa que dado un array de 10 componentes enteras, inicializado en declaración,
lleve a cabo la visualización, por cada componente del array, de tantos caracteres ‘*’ como
represente el contenido de la componente

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_9 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new Actividad_9().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        int [] asteriscos={10,2,2,3,6,7,5,4,0,1};
        //TRATAMIENTO
        //Subprograma para visualizar el resultado
        visualizarAsteriscos(asteriscos);
    }
    public void visualizarAsteriscos(int [] aster)throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<aster.length;indice++){
            for(int index=0;index<aster[indice];index++){
                System.out.print('*');
            }
            System.out.println();
        }
    }
}
