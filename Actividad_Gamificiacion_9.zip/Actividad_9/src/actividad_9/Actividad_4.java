/*
ENUNCIADO: declara 3 arrays de
10 componentes enteras. La inicialización de uno de ellos se lleva a cabo en declaración; la del
otro a través del teclado, y las componentes del tercero contendrán la suma de las componentes
de los otros dos por correspondencia posicional.

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_4 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new Actividad_4().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //CONSTANTES
        final int LONGITUD=10;
        //VARIABLES
        int [] array1={1,2,3,4,5,6,7,8,9,10};
        int [] array2=new int[LONGITUD];
        int [] array3=new int[LONGITUD];
        
        //TRATAMIENTO
        //Subprograma para visualizar el primer array
        visualizarArray1(array1);
        //Subprograma para obtener los elementos del array con valores introducidos por teclado
        rellenarArray(array2);
        //Subprograma para obtener el array resultante de la suma del primero y segundo
        resultadoArray(array1,array2,array3, LONGITUD);
        //Subprograma para visualizar el tercer array
        visualizarArray(array3);
    }
    public void visualizarArray1(int [] arrayD)throws Exception{
        System.out.print("EL PRIMER ARRAY ES ");
        //TRATAMIENTO
        for (int indice=0;indice<arrayD.length;indice++){
             System.out.print(arrayD[indice]+" ");
        }
        System.out.println();
    }
    public void rellenarArray(int [] arrayT)throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<arrayT.length;indice++){
            System.out.print("INTRODUZCA UN NÚMERO PARA OCUPAR LA "+(indice+1)+"º "
                    + "POSICIÓN DEL SEGUNDO ARRAY: ");
            arrayT[indice]=LT.readInt();
        }
    }
    public void resultadoArray(int [] arrayD,int [] arrayT,int [] arrayR,int LONG)throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<LONG;indice++){
            arrayR[indice]=arrayD[indice]+arrayT[indice];
        }
    }
    public void visualizarArray(int [] arrayR){
        //ACCIONES
        System.out.println("EL TERCER ARRAY ES :");
        //TRATAMIENTO
        for (int indice=0;indice<arrayR.length;indice++){
            System.out.println("COMPONENTE "+(indice+1)+": "+arrayR[indice]+" ");
        }
    }
}