/*
ENUNCIADO: Realizar un programa que solicite al usuario que introduzca por teclado 10 números enteros.
Posteriormente ha de visualizar el máximo y el mínimo de todos los números introducidos
acompañados del orden de introducción por teclado. Además también visualizar la media de los
números introducidos.

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_6 {
    //DECLARACIÓN ATRIBUTOS
    //CONSTANTES
    public static final int LONGITUD=10;
    //VARIABLES
    public static int [] numeros=new int[LONGITUD];
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception{
        new Actividad_6().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //VARIABLES
        int menor,mayor;
        float media;
        //TRATAMIENTO
        //Subprograma para leer los caracteres introducidos y almacenarlos en un array
        lecturaArray();
        //Subprograma para devolver el valor del menor entero de los introducidos en el array
        menor=menorArray();
        //Subprograma para devolver el valor del mayor entero de los intrducidos en el array
        mayor=mayorArray();
        //Subprograma para realizar la media aritmética de los valores introducidos en el array
        media=mediaArray();
        //Subprograma para visualizar el arraySystem.out.println("EL MAYOR VALOR DENTRO DEL ARARY ES "+mayor+"\nEL MENOR VALOR DENTROD EL ARRAY ES "+meno
        visualizarArray(menor,mayor,media);
    }
    public void lecturaArray()throws Exception{
        //TRATAMIENTO
        for (int indice=0;indice<numeros.length;indice++){
            System.out.print("INTRODUZCA UN NÚMERO ENTERO: ");
            numeros[indice]=LT.readInt();
        }    
    }
    public int menorArray()throws Exception{
        //DECLARACIONES
        int valorm=1;
        //TRATAMIENTO
        for (int indice=0;indice<numeros.length;indice++){
            if (valorm>numeros[indice]){
                valorm=numeros[indice];
            }
        }
        return(valorm);
    }
    public int mayorArray()throws Exception{
        //DECLARACIONES
        int valorM=1;
        //TRATAMIENTO
        for (int indice=0;indice<numeros.length;indice++){
            if (valorM<numeros[indice]){
                valorM=numeros[indice];
            }
        }
        return (valorM);
    }
    public float mediaArray()throws Exception{
        //DECLARACIONES
        float suma=0;
        for(int indice=0;indice<numeros.length;indice++){
            suma=suma+numeros[indice];
        }
        return(suma/LONGITUD);
    }
    public void visualizarArray(int men,int may, float med)throws Exception{
        //ACCIONES
        System.out.println("\nEL ARRAY INTRODUCIDO ES EL SIGUIENTE: ");
        //TRATAMIENTO
        for (int indice=0;indice<numeros.length;indice++){
            System.out.println("COMPONENTE "+(indice+1)+": "+numeros[indice]);
        }
        System.out.println("EL MAYOR DE LOS VALORES ES "+may+"\nEL MENOR DE LOS VALORES ES "+men);
        System.out.println("LA MEDIA ARITMÉTICA DE TODOS LOS VALORES INCLUIDOS EN EL ARRAY ES "+med);
    }
}
