/*
ENUNCIADO: Realizar un programa que solicite al usuario que introduzca por teclado una secuencia de
caracteres y visualice dicha secuencia invertida.
Nota: el número máximo de caracteres de la secuencia será de 100.

AUTOR: Alex Ortiz García
 */
package actividad_9;

public class Actividad_5 {
    //DECLARACIÓN ATRIBUTOS
    //CONSTANTES
    public static final int LONGITUD=100;
    public static final char FINAL='.';
    //VARIABLES
    public static char [] secuencia=new char[LONGITUD];
    public static int indice=0;
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args)throws Exception{
        new Actividad_5().metodoPrincipal();
    }
    public void metodoPrincipal()throws Exception{
        //DECLARACIONES
        //VARIABLE
        int posicion;
        //TRATAMIENTO
        //
        lecturaArray();
        //
        visualizarRevés();
    }
    public void lecturaArray()throws Exception{
        //DECLARACIONES
        char caracter;
        //ACCIONES
        System.out.print("""
                         INTRODUZCA UNA SECUENCIA DE CARACTERES
                         PARA FINALIZAR INTRODUZCA '.'
                         --->""");
        //
        caracter=LT.readChar();
        //
        secuencia[indice]=caracter;
        //
        indice++;
        //TRATAMIENTO
        while (caracter!=FINAL && indice<=LONGITUD){
            caracter=LT.readChar();
            if(caracter!=FINAL){
                //
                secuencia[indice]=caracter;
                //
                indice++;
            }
        }
    }
    public void visualizarRevés()throws Exception{
        //
        for (;indice>=0;indice--){
            System.out.print(secuencia[indice]);
        }
        System.out.println();
    }
}
