/*
ENUNCIADO:lleva a cabo la solución algorítmica y programa java del problema que 
visualiza el mensaje "PROGRAMACIÓN I - 2023" utilizando un subprograma, 
de identificador visualizacion, sin parámetros.
nota: en lugar de utilizar un literal String en el subprograma visualizacion se 
utiliza una constante de tipo String para ello.

ALGORITMO Mensaje2{
    DECLARACIÓN CONSTANTE STRING DE CLASE;
    EJECUCIÓN SUBPROGRAMA Test;
}
ALGORITMO SUBPROGRAMA Test{
    VISUALIZACIÓN CONSTANTE DE CLASE STRING;
}

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_5;

public class Actividad_1_2 {
    //DECLARACIÓN
    static final String mensaje="PROGRAMACIÓN I-2023";
    //DECLARACIÓN MÉTODO MAIN
    public static void main(String[] args) {
        Test();
    }
    public static void Test(){
        System.out.println(mensaje);
    }
}
