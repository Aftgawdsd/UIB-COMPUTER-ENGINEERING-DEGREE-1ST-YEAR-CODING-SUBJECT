/*
ENUNCIADO: Llevar a cabo la solución algorítmica y programa java del problema 
que dado un número entero mayor a cero, introducido por teclado, 
visualiza si el número es primo o no.
La verificación debe ser realizada a través de un subprograma.

ALGORITMO NUMPRIMO{
    LECTURA CARACTER;
    TRATAMIENTO;
    VISUALIZACIÓN RESULTADO;
}
ALGORITMO LECTURA CARACTER{
    VISUALIZACIÓN MENSAJE USUARIO;
    LECTURA CARÁCTER INTRODUCIDO;
}
ALGORITMO TRATAMIENTO{
    MIENTRAS EL CARÁCTER SEA MENOR A CERO{
        VISUALIZAR MENSAJE CORRESPONDIENTE;
        LECTURA CARÁCTER INTRODUCIDO;
    }
    EJECUCIÓN SUBPROGRAMA verificacionPrimo (PARÁMETROS: VARIABLE INT num);
}
ALGORITMO SUBPROGRAMA verificacionPrimo{
    DECLARACIÓN VARIABLES divisor Y contador;
    MIENTRAS LA VARIABLE divisor SEA MENOR O IGUAL A LA VARIABLE PARCIAL numSub{
        INCREMENTAR EN UNO LA VARIABLE DIVISOR;
        SI (numSub ENTRE divisor DA RESTO IGUAL A 0){
            INCREMENTAR EN UNO LA VARIABLE CONTADOR;
        }
    SI (VARIABLE contador MAYOR QUE 2){
        VISUALIZAR MENSAJE CORRESPONDIENTE;
    }
    SINO {
        VISUALIZAR MENSAJE CORRESPONDIENTE;
    }
}

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_5;

public class Actividad_4 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception{
        //DECLARACIÓN VARIABLES
        int num;
        
        //ACCIONES
        //Visualización Mensaje Usuario
        System.out.print("INTRODUZCA UN NÚMERO PARA VERIFICAR SI ES PRIMO O NO: ");
        //Lectura y almacenamiento de valor introducido en la variable num
        num=LT.readInt();
        
        //TRATAMIENTO      
        //Bucle iterativo WHILE
        while (num<=0){
            System.out.println("INTRODUZCA UN NÚMERO MAYOR QUE 0");
            System.out.print("INTRODUZCA UN NÚMERO PARA VERIFICAR SI ES PRIMO O NO: ");
            num=LT.readInt();
        }
        //SUBPROGRAMA
        verificacionPrimo(num);
    }
    public static void verificacionPrimo(int numSub) throws Exception{
        //DECLARACIÓN VARIABLES
        /*
        VARIABLE DIVISOR: ESTA INCREMENTARÁ EN 1 A CADA ITERACIÓN DEL BUCLE
        VARIABLE CONTADOR: ESTA INCREMENTARÁ CADA VEZ QUE EL RESTO DEL COCIENTE ENTRE 
                    VARIABLE PARCIAL numSub y VARIABLE divisor SEA IGUAL A 0
        */
        int divisor=1;
        int contador=0;
        
        //TRATAMIENTO
        //SENTENCIA ITERATIVA FOR
        for(;divisor<=numSub;divisor++){
            if (numSub%divisor==0){
                contador++;
            }
        }
        //SENTENCIA CONDICIONAL IF
        if (contador>2){
            System.out.println("EL NÚMERO "+numSub+" NO ES PRIMO. ES DIVISIBLE ENTRE "+contador+" NÚMEROS");
        }
        else {
            System.out.println("EL NÚMERO "+numSub+" ES PRIMO");
        }
    }
}
