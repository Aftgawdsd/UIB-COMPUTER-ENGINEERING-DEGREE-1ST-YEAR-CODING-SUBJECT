/*
ENUNCIADO:lleva a cabo la solución algorítmica y programa java del problema que 
visualiza el mensaje "PROGRAMACIÓN I - 2023" utilizando un subprograma 
sin parámetros, de identificador visualizacion, utilizando un literal String.

ALGORITMO Mensaje1{
    EJECUCIÓN SUBPROGRAMA Test;
}
ALGORITMO Test{
    DECLARACIÓN VARIABLE STRING;
    VISUALIZACIÓN VARIABLE STRING;
}
AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_5;


public class Actividad_1_1 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main(String[] args) {
        Test();
    }
    public static void Test(){
        String Mensaje="PROGRAMACIÓN I-2023";
        System.out.println(Mensaje);
    }
}
