/*
ENUNCIADO: Dada una secuencia de caracteres introducida por teclado y acabada con el carácter ‘.’ 
visualiza si el número de caracteres consonantes es par o impar.

ALGORITMO VocalParImpar{
    LECTURA CARÁCTER;
    TRATAMIENTO;
    VISUALIZACIÓN RESULTADO;
}
ALGORITMO LECTURA CARÁCTER{
    VISUALIZACIÓN MENSAJE USUARIO;
    LECTURA Y ALMACENAMIENTO CARÁCTER INTRODUCIDO;
}
ALGORITMO TRATAMIENTO{
    MIENTRAS (CARÁCTER INTRODUCIDO NO SEA CONSTANTE Final){
        SI (CARÁCTER INTRODUCIDO NO ES VOCAL NI ESPACIO){
            INCREMENTAR VARIABLE CONTADOR EN UNO;
        }
        LECTURA CARÁCTER INTRODUCIDO;
    }
    SI (VARIABLE CONTADOR ES PAR){
        VISUALIZAR MENSAJE CORRESPONDIENTE;
    }
    SI (VARIABLE CONTADOR ES IMPAR){
        VISUALIZAR MENSAJE CORRESPONDIENTE;
    }
    SI (VARIABLE CONTADOR ES 0){
        VISUALIZAR MENSAJE CORRESPONDIENTE;
    }
}

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_5;

public class Actividad_8 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception{
        //DECLARACIÓN CONSTANTES
        final char Final='.';
        final char Espacio=' ';
        //DECLARACIÓN VARIABLES
        char caracter;
        int contador;
        
        //ACCIONES
        //Visualización Mensaje Usuario
        System.out.print("""
                         INTRODUZCA UNA SECUENCIA DE CARACTERES
                         PARA FINALIZAR INTRODUZCA '.'
                         --> """);
        //Lectura y almacenamiento de carácter en la variable caracter
        caracter=LT.readChar();
        
        //TRATAMIENTO
        //INICIALIZACIÓN VARIABLE CONTADOR
        contador=0;
        //Sentencia Iterativa While
        while (caracter!=Final){
            if (caracter!='a' && caracter!='e' && caracter!='i' && 
                    caracter!='o' && caracter!='u' && caracter!=Espacio){
                contador++;
            }
            caracter=LT.readChar();
        }
        if (contador==0){
            System.out.println("NO HAY CONSONANTES EN LA SECUENCIA");
        }
        else if (contador%2==0){
            System.out.println("HAY UN NÚMERO PAR DE CONSONANTES EN LA SECUENCIA");
        }
        else {
            System.out.println("HAY UN NÚMERO IMPAR DE CONSONANTES EN LA SECUENCIA");
        }
    }
}
