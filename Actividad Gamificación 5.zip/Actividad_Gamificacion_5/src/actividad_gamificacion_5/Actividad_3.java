/*
ENUNCIADO: Llevar a cabo la solución algorítmica y programa java del problema 
que dado un número entero, introducido por teclado, visualiza si el número es 
múltiplo de 7. La verificación de si el número es múltiplo de 7 debe ser 
realizada a través de un subprograma.

ALGORITMO MULTIPLODE7{
    DECLARACIÓN CONSTANTES;
    LECTURA CARÁCTER;
    TRATAMIENTO;
    VISUALIZACIÓN RESULTADO;
}
ALGORITMO LECTURA CARÁCTER{
    VISUALIZACIÓN MENSAJE USUARIO;
    LECTURA Y ALMACENAMIENTO DE CARÁCTER INTRODUCIDO;
}
ALGORITMO TRATAMIENTO{
    EJECUCIÓN SUBPROGRAMA Multiplo7 (PARÁMETRO: VARIABLE INT num, CONSTANTE INT divisor);
}
ALGORITMO SUBPROGRAMA Multiplo7{
    SI EL RESTO DEL COCIENTE ENTRE VARIABLE PARCIAL num y CONSTANTE PARCIAL divisor ES IGUAL A 0{
        VISUALIZAR MENSAJE CORRESPONDIENTE;
    }
    SINO {
        VISUALIZAR MENSAJE CORRRESPONDIENTE;
    }
}

AUTOR:Alex Ortiz García
 */
package actividad_gamificacion_5;

public class Actividad_3 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception{
        //DECLARACIÓN CONSTANTES
        final int divisor=7;
        //DECLARACIÓN VARIABLES
        int num;
        
        //ACCIONES
        //Visualización Mensaje Usuario
        System.out.print("INTRODUZCA UN NÚMERO MÚLTIPLO DE 7: ");
        //Lectura y almacenamiento de valor introducido en variable num
        num=LT.readInt();
        
        //TRATAMIENTO
        //Subprograma
        Multiplo7(num, divisor);
    }
    public static void Multiplo7 (int numSub, final int divisorSub){
        if (numSub%divisorSub==0){
            System.out.println("EL NÚMERO "+numSub+" ES DIVISIBLE POR "+divisorSub);
        }
        else {
            System.out.println("EL NÚMERO "+numSub+" NO ES DIVISIBLE POR "+divisorSub);
        }
    }
}
