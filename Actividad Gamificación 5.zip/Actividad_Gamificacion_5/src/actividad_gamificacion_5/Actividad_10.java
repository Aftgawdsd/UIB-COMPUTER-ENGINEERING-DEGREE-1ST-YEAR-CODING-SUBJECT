/*
ENUNCIADO: Dada una secuencia de caracteres introducida por teclado y acabada con el carácter ‘.’ 
verifica si todos los caracteres de la secuencia son alfabéticos.
Ejemplo:
Secuencia de caracteres introducida por teclado: hoy es viernes.
Salida por pantalla: EN LA SECUENCIA NO TODOS LOS CARACTERES SON ALFABÉTICOS

ALGORITMO Alfabéticos{
    LECTURA CARÁCTER;
    TRATAMIENTO;
    VISUALIZACIÓN RESULTADO;
}
ALGORITMO LECTURA CARÁCTER{
    VISUALIZACIÓN MENSAJE USUARIO;
    LECTURA Y ALMACENAMIENTO CARÁCTER INTRODUCIDO;
}
ALGORITMO TRATAMIENTO{
    INICIALIZACIÓN VARIABLE ascii (CONTIENE EL VALOR ASCII DE VARIABLE caracter);
    MIENTRAS (CARÁCTER INTRODUCIDO NO SEA CONSTANTE Final){
        SI (VARIABLE ascii MENOR QUE 97 O MAYOR QUE 122){
            VISUALIZAR MENSAJE CORRESPONDIENTE;
            VARIABLE BOOLEANA alfa PASA A SER FALSA;
            SENTENCIA BREAK;
        }
        LECTURA CARÁCTER INTRODUCIDO;
        VARIABLE ascii= CASTING A INT DE VARIABLE caracter;
    }
}
ALGORITMO VISUALIZACIÓN RESULTADO{
    SI (VARIABLE BOOLEANA alfa ES VERDADERA){
        VISUALIZAR MENSAJE CORRESPONDIENTE;
    }
}

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_5;

public class Actividad_10 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception {
       //DECLARACIÓN CONSTANTES
       final char Final='.';
       final char Espacio=' ';
       //DECLARACIÓN VARIABLES
       char caracter;
       int ascii;
       boolean alfa=true;
       
       //ACCIONES
       //Visualización mensaje usuario
       System.out.print("""
                        INTRODUZCA UNA SECUENCIA DE CARACTERES
                        PARA FINALIZAR INTRODUZCA '.'
                        ---> """);
       //Lectura y almacenamiento de carácter en la variable caracter
       caracter=LT.readChar();
       
       //TRATAMIENTO
       //INICIALIZACIÓN VARIABLE ASCII
       ascii=(int)caracter;
       //Sentencia iterativa while
       while(caracter!=Final){
           if ((ascii<97)||(ascii>122)){
               System.out.println("NO TODOS LOS CARACTERES EN LA SECUENCIA SON ALFABÉTICOS");
               alfa=false;
               break;
           }    
           caracter=LT.readChar();
           ascii=(int)caracter;
       }
       if (alfa==true){
           System.out.println("TODOS LOS CARACTERES DE LA SECUENCIA SON ALFABÉTICOS");
       }
    }
}
