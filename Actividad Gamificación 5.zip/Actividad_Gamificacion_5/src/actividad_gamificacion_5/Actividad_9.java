/*
ENUNCIADO: Dada una secuencia de caracteres introducida por teclado y acabada con el carácter ‘.’ 
Verifica si en la secuencia hay el doble de caracteres consonantes que caracteres vocales.
Ejemplo:
Secuencia de caracteres introducida por teclado: hoy es viernes.
Salida por pantalla: NO

ALGORITMO ConsonanteDobleVocal{
    LECTURA CARÁCTER;
    TRATAMIENTO;
    VISUALIZACIÓN RESULTADO;
}
ALGORITMO LECTURA CARÁCTER{
    VISUALIZACIÓN MENSAJE USUARIO;
    LECTURA CARÁCTER INTRODUCIDO;
}
ALGORITMO TRATAMIENTO{
    INICIALIZACIÓN VARIABLES CONTADOR;
    MIENTRAS (CARÁCTER INTRODUCIDO NO SEA CONSTANTE FINAL){
        SI (CARÁCTER INTRODUCIDO ES VOCAL){
            INCREMENTAR EN UNO VARIABLE contadorV;
        }
        SI (CARÁCTER INTRODUCIDO NO ES VOCAL NI CONSTANTE Espacio){ 
            INCREMENTAR EN UNO VARIABLE contadorC;
        }
    }
}
ALGORITMO VISUALIZACIÓN RESULTADO{
    SI (VARIABLE contadorC ES IGUAL AL DOBLE DE VARIABLE contadorV){
        VISUALIZAR MENSAJE CORRESPONDIENTE;
    SINO{
        VISUALIZAR MENSAJE CORRESPONDIENTE;
    }
}

AUTOR: Alex Ortiz García 
 */
package actividad_gamificacion_5;

public class Actividad_9 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception{
        //DECLARACIÓN CONSTANTES
        final char Final='.';
        final char Espacio=' ';
        //DECLARACIÓN VARIABLES
        char caracter;
        int contadorV,contadorC;
        
        //ACCIONES
        //Visualización mensaje usuario
        System.out.print("""
                         INTRODUZCA UNA SECUENCIA DE CARACTERES
                         PARA FINALIZAR INTRODUZCA '.'
                         ---> """);
        //Lectura y almacenamiento de carácter introducido en la variable caracter
        caracter=LT.readChar();
        
        //TRATAMIENTO
        //INICIALIZACIÓN VARIABLES CONTADOR
        contadorV=0;
        contadorC=0;
        //Sentencia iterativa While
        while (caracter!=Final){
            if (caracter=='a' || caracter=='e' || caracter=='i' || caracter=='o' || caracter=='u'){
                contadorV++;
            }
            else if (caracter!='a' && caracter!='e' && caracter!='i' && 
                    caracter!='o' && caracter!='u' && caracter!=Espacio){
                contadorC++;
            }
            caracter=LT.readChar();
        }
        if (contadorC==2*contadorV){
            System.out.println("SI");
        }
        else {
            System.out.println("NO");
        }
    }
}
