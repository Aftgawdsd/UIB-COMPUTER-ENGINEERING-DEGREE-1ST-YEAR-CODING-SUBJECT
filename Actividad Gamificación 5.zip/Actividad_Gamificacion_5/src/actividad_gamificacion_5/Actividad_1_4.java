/*
ENUNCIADO:lleva a cabo la solución algorítmica y programa java del problema que 
visualiza el mensaje "PROGRAMACIÓN I - 2023" utilizando un subprograma,
de identificador visualizacion, con parámetros.
nota: el mensaje a visualizar a través del subprograma visualización se 
transfiere como parámetro variable String en la llamada dentro del método main.

ALGORITMO Mensaje4{
    DECLARACIÓN VARIABLE STRING;
    EJECUCIÓN SUBPROGRAMA Test CON PARÁMETRO (VARIABLE STRING);
}
ALGORITMO SUBPROGRAMA Test{
    VISUALIZACIÓN VARIABLE PARCIAL;
}

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_5;

public class Actividad_1_4 {
    
    //DECLARACIÓN MÉTODO MAIN
    public static void main(String[] args) {
        String mensaje="PROGRAMACIÓN I-2023";
        Test(mensaje);
    }
    public static void Test(String mens){
        System.out.println(mens);
    }
}
