/*
ENUNCIADO: Dada una secuencia de caracteres introducida por teclado y acabada con el carácter ‘.’ 
visualiza la secuencia en pantalla de forma que cada carácter alfabético minúscula 
será visualizado a través de su carácter alfabético mayúscula correspondiente.
Ejemplo:
Secuencia de caracteres introducida por teclado: hoy es viernes.
Salida por pantalla: HOY ES VIERNES

ALGORITMO MinusAMayus{
    LECTURA CARACTERES;
    TRATAMIENTO;
    VISUALIZACIÓN RESULTADO;
{
ALGORITMO LECTURA CARACTERES{
    VISUALIZACIÓN MENSAJE USUARIO;
    LECTURA CARÁCTER INTRODUCIDO;
}
ALGORITMO TRATAMIENTO{
    MIENTRAS (CARACTER INTRODUCIDO NO SEA CONSTANTE Final){
        SI (CARACTER INTRODUCIDO NO ES ESPACIO Y ES ALFABÉTICO MINÚSCULA){
                VARIABLE caracter --> CASTING A INT Y RESTARLE 32 
                (SI ES ALFABÉTICO, PASARÁ SU VALOR AL ASCII DE SU RESPECTIVA MAYÚSCULA);
                VISUALIZAR CARÁCTER ALFABÉTICO MAYÚSCULA;
        }
        SINO {
            VISUALIZAR CARÁCTER INTRODUCIDO;
        }
        LECTURA CARÁCTER INTRODUCIDO;
}
ALGORITMO VISUALIZACIÓN RESULTADO{
    MENSAJE INTRODUCIDO CONVIRTIENDO LOS CARÁCTERES ALFABÉTICOS MINÚSCULA A MAYÚSCULA;
}


AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_5;

public class Actividad_6 {
    //DECLARACIÓN MÉTODO MAIN 
    public static void main (String [] args) throws Exception {
        //DECLARACIÓN CONSTANTES
        final char Final='.';
        final char Espacio=' ';
        //DECLARACIÓN VARIABLES
        char caracter;
        
        //ACCIONES
        //Visualización mensaje usuario
        System.out.print("""
                         INTRODUZCA UNA SECUENCIA DE CARACTERES
                         PARA FINALIZAR INTRODUZCA '.'
                         ---> """);
        //Lectura y almacenamiento del carácter introducido en la variable caracter
        caracter=LT.readChar();
        
        //TRATAMIENTO
        //Sentencia iterativa WHILE
        while (caracter!=Final){
            if (caracter!=Espacio && ((int)caracter>=97 && (int)caracter<=122)){
                caracter=(char)((int)caracter-32);
                System.out.print(caracter);
            }
            else {
                System.out.print(caracter);
            }
            caracter=LT.readChar();
        }
        System.out.println("");
    }
}
