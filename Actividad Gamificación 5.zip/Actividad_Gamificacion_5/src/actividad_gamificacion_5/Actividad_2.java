/*
ENUNCIADO: Llevar a cabo la solución algorítmica y programa java del problema 
que dado dos números introducidos por teclado visualiza el menor de los dos. 
Debe ser utilizado un subprograma para saber cuál de los dos números es menor.

ALGORITMO MAYORYMENOR{
    LECTURA CARACTERES;
    TRATAMIENTO;
    VISUALIZACIÓN RESULTADO;
}
ALGORITMO LECTURA CARACTERES{
    VISUALIZACIÓN MENSAJE USUARIO;
    LECTURA Y ALMACENAMIENTO CARÁCTER INTRODUCIDO;
    VISUALIZACIÓN MENSAJE USUARIO;
    LECTURA Y ALMACENAMIENTO CARÁCTER INTRODUCIDO;
}
ALGORITMO TRATAMIENTO{
    EJECUCIÓN SUBPROGRAMA MayorMenor (PARÁMETROS: VARIABLES INT num1 Y num2);
}
ALGORITMO SUBPROGRAMA MayorMenor{
    SI (num1>num2){
        VISUALIZA EL MENSAJE CORRESPONDIENTE;
    }
    SI (num1<num2){
        VISUALIZA EL MENSAJE CORRESPONDIENTE;
    }
    SINO{
        VISUALIZA EL MENSAJE CORRESPONDIENTE;
    }
}

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_5;

public class Actividad_2 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception {
        //DECLARACIÓN DE VARIABLES
        int num1, num2;
        
        //ACCIONES
        //Visualización Mensaje Usuario
        System.out.print("INTRODUZCA UN NÚMERO: ");
        //Lectura y almacenamiento de valor introducido en la variable num1
        num1=LT.readInt();
        //Visualización Mensaje Usuario
        System.out.print("INTRODUZCA OTRO NÚMERO: ");
        //Lectura y almacenamiento de valor introducido en variable num2
        num2=LT.readInt();
        
        //TRATAMIENTO
        //EJECUCIÓN SUBPROGRAMA
        MayorMenor(num1,num2);
    }
    //SUBPROGRAMA
    public static void MayorMenor(int num1sub,int num2sub) throws Exception{
        //SENTENCIA CONDICIONAL IF
        if (num1sub>num2sub){
            System.out.println("DE LOS NÚMEROS "+num1sub+" Y "+num2sub+", EL NÚMERO "+num1sub+" ES MAYOR.");
        }
        else if (num2sub>num1sub) {
            System.out.println("DE LOS NÚMEROS "+num1sub+" Y "+num2sub+", EL NÚMERO "+num2sub+" ES MAYOR.");
        }
        else {
            System.out.println("AMBOS NÚMEROS SON IGUALES.");
        }
    }
}
