/*
ENUNCIADO:Dada una secuencia de caracteres introducida por teclado y acabada 
coen el carácter ‘.’ visualiza el número de caracteres vocales, 
el número de caracteres consonantes y el número de caracteres espacio ‘ ’ 
contenidos en la secuencia.

ALGORITMO VOCCONESP{
    LECTURA CARACTERES;
    TRATAMIENTO;
    VISUALIZACIÓN RESULTADO;
}
ALGORITMO LECTURA CARACTERES{
    VISUALIZACIÓN MENSAJE USUARIO;
    LECTURA Y ALMACENAMIENTO DE CARÁCTER INTRODUCIDO;
}
ALGORITMO TRATAMIENTO{
    ININICIALIZACIÓN VARIABLES CONTADOR;
    MIENTRAS (CARÁCTER INTRODUCIDO NO SEA CONSTANTE Final){
        SI (CARÁCTER INTRODUCIDO ES CONSTANTE Espacio){
            AUMENTAR EN UNO CONTADOR1;
        }
        SI (CARÁCTER INTRODUCIDO NO ES VOCAL){
            AUMENTAR EN UNO CONTADOR2;
        }
        SI (CARÁCTER INTRODUCIDO ES VOCAL){
            AUMENTAR EN UNO CONTADOR3;
        }
        LECTURA Y ALMACENAMIENTO CARÁCTER INTRODUCIDO;
    }
}
ALGORITMO VISUALIZACIÓN RESULTADO{
    VISUALIZAR MENSAJE Y VARIABLES CONTADOR;
}

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_5;

public class Actividad_5 {
    //DECLARACIÓN MÉTODO MAIN
    public static void main (String [] args) throws Exception {
        //DECLARACIÓN CONSTANTES
        final char Final='.';
        final char Espacio=' ';
        //DECLARACIÓN VARIABLES
        char caracter;
        int contador1, contador2, contador3;
        
        //ACCIONES
        //Visualización Mensaje Usuario
        System.out.print("""
                         INTRODUZCA UNA SECUENCIA DE CARACTERES
                         PARA FINALIZAR INTRODUZCA '.'
                         --> """);
        //Lectura y almacenamiento del caracter introducido en la variable caracter
        caracter=LT.readChar();
        
        //TRATAMIENTO
        //INICIALIZACIÓN VARIABLES CONTADOR
        contador1=0;
        contador2=0;
        contador3=0;
        //Sentencia Iterativa While
        while (caracter!=Final) {
            if (caracter==Espacio){
                contador1++;
            }
            else if (caracter!='a' && caracter!='e' && caracter!='i' && 
                    caracter!='o' && caracter!='u' && caracter!=Espacio) {
                contador2++;
            }
            else if (caracter=='a' || caracter=='e' || caracter=='i' || caracter=='o' || caracter=='u'){
                contador3++;
            }
            caracter=LT.readChar();
        }
        //VISUALIZACIÓN RESULTADO
        System.out.println("EN LA SECUENCIA INTRODUCIDA HAY "+contador3+" "
                + "VOCALES, "+contador2+" CONSONANTES Y "+contador1+" ESPACIOS.");
    }
}
