/*
ENUNCIADO: lleva a cabo la solución algorítmica y programa java del problema que 
visualiza el mensaje "PROGRAMACIÓN I - 2023" utilizando un subprograma, 
de identificador visualizacion, con parámetros.
nota: el mensaje a visualizar a través del subprograma visualización se 
transfiere como parámetro literal String en la
llamada dentro del método main.

ALGORITMO Mensaje3{
    DECLARACIÓN CONSTANTE STRING;
    EJECUCION SUBPROGRAMA Test CON PARÁMETRO (CONSTANTE STRING);
}
ALGORITMO SUBPROGRAMA Test{
    VISUALIZACIÓN CONSTANTE PARCIAL STRING;
}

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_5;

public class Actividad_1_3 {
    
    //DECLARACIÓN MÉTODO MAIN
    public static void main(String[] args) {
        final String mensaje="PROGRAMACIÓN I-2023";
        Test(mensaje);
    }
    public static void Test(String mens){
        System.out.println(mens);
    }
}
