/*
ENUNCIADO: Dada una secuencia de caracteres, introducida por teclado y acabada con el carácter
'.', visualizar el número de palabras que tengan el mismo número de vocales que
consonantes.

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_6;

public class Actividad_4 {
    private static char caracter;
    public static char Espacio=' ';
    public static char Final='.';
    
    public static void main(String[] args) throws Exception {
        //DECLARACIÓN CONSTANTES
        //DECLARACIÓN VARIABLES
        int palabras;
        //ACCIONES
        //Visualización Mensaje Usuario
        System.out.print("""
                         INTRODUZCA UNA SECUENCIA DE CARACTERES
                         PARA FINALIZAR INTRODUZCA '.'
                         --->""");
        //Lectura y almacenamiento de caracter introducido en la variable caracter
        caracter=LT.readChar();
        
        //TRATAMIENTO
        //INICIALIZACIÓN VARIABLES CONTADOR
        palabras=0;
        
        buscarPalabra();
        //SENTENCIA ITERATIVA WHILE
        while (caracter!=Final){
            if (vocalCons()==true){
                palabras++;
            }
            buscarPalabra();

        }
        System.out.println("EL NÚMERO DE PALABRAS CON EL MISMO NÚMERO DE VOCALES QUE DE CONSONANTES ES "+palabras);
    }
    public static void buscarPalabra() throws Exception{
        while (caracter==Espacio){
            caracter=LT.readChar();
        }
    }
    public static boolean vocalCons() throws Exception{
        boolean vocalCons=false;
        int vocal, cons;
        vocal=0;
        cons=0;
        while (caracter!=Espacio && caracter!=Final){
            if (caracter=='a' || caracter=='e' || caracter=='i' || caracter=='o' || caracter=='u'){
                vocal++;
            }
            else if (caracter!='a' && caracter!='e' && caracter!='i' && caracter!='o' && caracter!='u'){
                cons++;
            }
            caracter=LT.readChar();
        }
        if (vocal==cons){
            vocalCons=true;
        }
        return (vocalCons);
    }
}
