/*
ENUNCIADO: Dada una secuencia de caracteres introducida por teclado y acabada con el carácter '.',
visualizar el número de palabras que acaben con el carácter 'o'.

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_6;

public class Actividad_3 {
    //DECLARACIÓN ATRIBUTOS CLASE
    static final char Final='.';
    static final char Espacio=' ';
    static char caracter1, caracter2;
    //DECLARACIÓN MÉTODO MAIN
    public static void main(String [] args) throws Exception{
        //DECLARACIÓN VARIABLES
        int palabras;
        
        //ACCIONES
        //Visualizar Mensaje Usuario
        System.out.print("""
                         INTRODUZCA UNA SECUENCIA DE CARACTERES
                         PARA FINALIZAR INTRODUZCA '.'
                         --->""");
        //Lectura y almacenamiento de caracteres en variable caracter
        
        caracter2=LT.readChar();
        //TRATAMIENTO
        //INICIALIZACIÓN VARIABLE CARACTER1
        caracter1=Espacio;
        
        palabras=0;
        
        buscarPalabra();
        //
        while (caracter2!=Final){
            if (palabraO()==true){
                palabras++;
            }
            buscarPalabra();
        }
        System.out.println("EL NÚMERO DE PALABRAS QUE ACABAN POR 'o' ES "+palabras);
        
    }
    public static void buscarPalabra() throws Exception{
        while (caracter2==Espacio){
            caracter1=caracter2;
            caracter2=LT.readChar();
        }
    }
    public static boolean palabraO() throws Exception{
        boolean a=false;
        while (caracter1!=Espacio && caracter1!=Final){
            if (caracter1=='o' && (caracter2==Espacio || caracter2==Final)){
                a=true;
            }
        }
        return(a);
    }
    
}
