/*
ENUNCIADO: Dada una secuencia de caracteres, introducida por teclado y acabada con el carácter
'.', visualizar el número de palabras que tengan un número par de caracteres.

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_6;

public class Actividad_5 {
    private static char caracter;
    public static char Espacio=' ';
    public static char Final='.';
    
    public static void main(String[] args) throws Exception {
        //DECLARACIÓN CONSTANTES
        //DECLARACIÓN VARIABLES
        int palabras;
        //ACCIONES
        //Visualización Mensaje Usuario
        System.out.print("""
                         INTRODUZCA UNA SECUENCIA DE CARACTERES
                         PARA FINALIZAR INTRODUZCA '.'
                         --->""");
        //Lectura y almacenamiento de caracter introducido en la variable caracter
        caracter=LT.readChar();
        
        //TRATAMIENTO
        //INICIALIZACIÓN VARIABLES CONTADOR
        palabras=0;
        
        buscarPalabra();
        //SENTENCIA ITERATIVA WHILE
        while (caracter!=Final){
            if (palabraPar()==true){
                palabras++;
            }
            buscarPalabra();

        }
        System.out.println("EL NÚMERO DE PALABRAS CON NÚMERO DE CARACTERES PAR ES "+palabras);
    }
    public static void buscarPalabra() throws Exception{
        while (caracter==Espacio){
            caracter=LT.readChar();
        }
    }
    public static boolean palabraPar() throws Exception{
        boolean par=false;
        int car=0;
        while (caracter!=Espacio && caracter!=Final){
            car++;
            caracter=LT.readChar();
        }
        if (car%2==0){
            par=true;
        }
        return (par);
    }
}
