/*
ENUNCIADO: Dada una secuencia de caracteres introducida por teclado y acabada con el carácter '.',
visualizar el número de palabras que contengan el carácter 'z'.
 */
package actividad_gamificacion_6;

public class Actividad_1 {
    private static char caracter;
    public static char Espacio=' ';
    public static char Final='.';
    
    public static void main(String[] args) throws Exception {
        //DECLARACIÓN CONSTANTES
        //DECLARACIÓN VARIABLES
        int palabras;
        //ACCIONES
        //Visualización Mensaje Usuario
        System.out.print("""
                         INTRODUZCA UNA SECUENCIA DE CARACTERES
                         PARA FINALIZAR INTRODUZCA '.'
                         --->""");
        //Lectura y almacenamiento de caracter introducido en la variable caracter
        caracter=LT.readChar();
        
        //TRATAMIENTO
        //INICIALIZACIÓN VARIABLES CONTADOR
        palabras=0;
        
        buscarPalabra();
        //SENTENCIA ITERATIVA WHILE
        while (caracter!=Final){
            if (palabraZ()==true){
                palabras++;
            }
            buscarPalabra();

        }
        System.out.println("EL NÚMERO DE PALABRAS CON EL CARÁCTER 'Z' ES "+palabras);
    }
    public static void buscarPalabra() throws Exception{
        while (caracter==Espacio){
            caracter=LT.readChar();
        }
    }
    public static boolean palabraZ() throws Exception{
        boolean z=false;
        while (caracter!=Espacio && caracter!=Final){
            if (caracter=='z'){
                z=true;
            }
            caracter=LT.readChar();
        }
        return (z);
    }
}
