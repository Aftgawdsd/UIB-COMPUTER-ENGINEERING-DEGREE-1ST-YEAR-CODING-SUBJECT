/*
ENUNCIADO: Dada una secuencia de caracteres introducida por teclado y acabada con el carácter '.',
visualizar el número de palabras que empiecen con el carácter 'a'.

AUTOR: Alex Ortiz García
 */
package actividad_gamificacion_6;

public class Actividad_2 {
    //DECLARACIÓN ATRIBUTOS CLASE
    static final char Final='.';
    static final char Espacio=' ';
    static char caracter1, caracter2;
    //DECLARACIÓN MÉTODO MAIN
    public static void main(String [] args) throws Exception{
        //DECLARACIÓN VARIABLES
        int palabras;
        
        //ACCIONES
        //Visualizar Mensaje Usuario
        System.out.print("""
                         INTRODUZCA UNA SECUENCIA DE CARACTERES
                         PARA FINALIZAR INTRODUZCA '.'
                         --->""");
        //Lectura y almacenamiento de caracteres en variable caracter
        
        caracter2=LT.readChar();
        //TRATAMIENTO
        //INICIALIZACIÓN VARIABLE CARACTER1
        caracter1=Espacio;
        
        palabras=0;
        
        buscarPalabra();
        //
        while (caracter2!=Final){
            if (palabraA()==true){
                palabras++;
            }
            buscarPalabra();
        }
        System.out.println("EL NÚMERO DE PALABRAS QUE EMPIEZAN POR 'a' ES "+palabras);
        
    }
    public static void buscarPalabra() throws Exception{
        while (caracter2==Espacio){
            caracter1=caracter2;
            caracter2=LT.readChar();
        }
    }
    public static boolean palabraA() throws Exception{
        boolean a=false;
        while (caracter2!=Espacio && caracter2!=Final){
            if (caracter1==Espacio && caracter2=='a'){
                a=true;
            }
            caracter1=caracter2;
            caracter2=LT.readChar();
        }
        return(a);
    }
    
}
